<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('travel_requests', function (Blueprint $table) {
            $table->id();

            // Customer basic details
            $table->string('customer_name');
            $table->string('email')->nullable();
            $table->string('phone');

            // Travel requirement
            $table->string('destination');
            $table->string('departure_city')->nullable();
            $table->date('travel_date')->nullable();
            $table->string('travel_month')->nullable();

            // AI / selected plan details
            $table->string('selected_plan')->nullable();
            $table->unsignedTinyInteger('duration_days')->nullable();

            // Traveller details
            $table->unsignedInteger('travellers')->default(1);
            $table->unsignedInteger('adults')->nullable();
            $table->unsignedInteger('children')->nullable();

            // Budget and hotel preference
            $table->decimal('budget', 12, 2)->nullable();
            $table->string('hotel_category')->nullable();

            // Notes and AI fields
            $table->text('notes')->nullable();
            $table->text('missing_details')->nullable();
            $table->text('ai_summary')->nullable();
            $table->longText('ai_draft_plan')->nullable();

            // Marketplace workflow
            $table->string('status')->default('New Request');

            $table->foreignId('claimed_by_organization_id')
                ->nullable()
                ->constrained('organizations')
                ->nullOnDelete();

            $table->foreignId('converted_lead_id')
                ->nullable()
                ->constrained('leads')
                ->nullOnDelete();

            $table->timestamp('claimed_at')->nullable();
            $table->timestamp('converted_at')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('travel_requests');
    }
};
