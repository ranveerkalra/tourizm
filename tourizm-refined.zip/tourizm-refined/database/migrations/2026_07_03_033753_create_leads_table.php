<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
   public function up(): void
{
    Schema::create('leads', function (Blueprint $table) {

        $table->id();

        // Organization (Multi-Tenant)
        $table->foreignId('organization_id')
              ->constrained()
              ->cascadeOnDelete();

        // Assigned Consultant
        $table->foreignId('assigned_to')
              ->nullable()
              ->constrained('users')
              ->nullOnDelete();

        // Customer Details
        $table->string('customer_name');
        $table->string('email')->nullable();
        $table->string('phone');

        // Travel Details
        $table->string('destination');
        $table->date('travel_date')->nullable();
        $table->integer('travellers')->default(1);
        $table->decimal('budget', 12, 2)->nullable();

        // Lead Source
        $table->enum('source', [
            'Website',
            'WhatsApp',
            'Walk-in',
            'Referral',
            'Instagram',
            'Facebook',
            'Call',
            'Other'
        ])->default('Website');

        // Lead Status
        $table->enum('status', [
            'New',
            'Contacted',
            'Qualified',
            'Quotation Sent',
            'Won',
            'Lost'
        ])->default('New');

        $table->text('notes')->nullable();

        $table->timestamps();
    });
}
    /**
     * Reverse the migrations.
     */
    public function down(): void
{
    Schema::dropIfExists('leads');
}
};
