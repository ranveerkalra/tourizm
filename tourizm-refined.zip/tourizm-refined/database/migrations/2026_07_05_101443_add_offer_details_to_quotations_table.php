<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('quotations', function (Blueprint $table) {
            $table->unsignedInteger('duration_days')->nullable()->after('travel_end_date');
            $table->unsignedInteger('adults')->nullable()->after('travellers');
            $table->unsignedInteger('children')->nullable()->after('adults');
            $table->string('hotel_category')->nullable()->after('children');

            $table->text('itinerary_summary')->nullable()->after('notes');
            $table->text('inclusions')->nullable()->after('itinerary_summary');
            $table->text('exclusions')->nullable()->after('inclusions');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('quotations', function (Blueprint $table) {
            $table->dropColumn([
                'duration_days',
                'adults',
                'children',
                'hotel_category',
                'itinerary_summary',
                'inclusions',
                'exclusions',
            ]);
        });
    }
};
