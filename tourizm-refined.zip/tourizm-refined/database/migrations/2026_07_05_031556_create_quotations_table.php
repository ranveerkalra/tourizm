<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('quotations', function (Blueprint $table) {
            $table->id();

            // Multi-tenant organization ownership
            $table->foreignId('organization_id')
                ->constrained()
                ->cascadeOnDelete();

            // Customer linked to this quotation
            $table->foreignId('customer_id')
                ->constrained()
                ->cascadeOnDelete();

            // Optional lead linked to this quotation
            $table->foreignId('lead_id')
                ->nullable()
                ->constrained()
                ->nullOnDelete();

            // User who created the quotation
            $table->foreignId('created_by')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            // Quotation details
            $table->string('quotation_number')->unique();
            $table->string('title');
            $table->string('destination')->nullable();

            // Travel details
            $table->date('travel_start_date')->nullable();
            $table->date('travel_end_date')->nullable();
            $table->unsignedInteger('travellers')->default(1);

            // Financial details
            $table->decimal('subtotal', 12, 2)->default(0);
            $table->decimal('discount', 12, 2)->default(0);
            $table->decimal('tax', 12, 2)->default(0);
            $table->decimal('total_amount', 12, 2)->default(0);
            $table->string('currency', 10)->default('INR');

            // Status flow: Draft, Sent, Accepted, Rejected
            $table->string('status')->default('Draft');

            // Validity and notes
            $table->date('valid_until')->nullable();
            $table->text('notes')->nullable();
            $table->text('terms')->nullable();

            $table->timestamps();

            // Helpful indexes for filtering/search later
            $table->index(['organization_id', 'status']);
            $table->index(['organization_id', 'customer_id']);
            $table->index(['organization_id', 'created_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('quotations');
    }
};
