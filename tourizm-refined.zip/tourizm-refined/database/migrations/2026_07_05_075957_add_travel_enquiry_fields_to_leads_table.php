<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('leads', function (Blueprint $table) {
            $table->unsignedInteger('duration_days')->nullable()->after('travel_date');
            $table->unsignedInteger('adults')->nullable()->after('duration_days');
            $table->unsignedInteger('children')->nullable()->after('adults');
            $table->string('hotel_category')->nullable()->after('children');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('leads', function (Blueprint $table) {
            $table->dropColumn([
                'duration_days',
                'adults',
                'children',
                'hotel_category',
            ]);
        });
    }
};
