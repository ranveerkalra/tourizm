<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('organizations', function (Blueprint $table) {
            $table->id();

            $table->string('name');
            $table->string('slug')->unique();

            $table->enum('type', [
                'travel_agency',
                'dmc',
                'supplier'
            ])->default('travel_agency');

            $table->string('email')->nullable();
            $table->string('phone')->nullable();

            $table->enum('status', [
                'pending',
                'active',
                'suspended'
            ])->default('active');

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('organizations');
    }
};
