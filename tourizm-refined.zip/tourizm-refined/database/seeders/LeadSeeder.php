<?php

namespace Database\Seeders;

use App\Models\Lead;
use App\Models\TravelRequest;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class LeadSeeder extends Seeder
{
    public function run(): void
    {
        $user = User::where('role', 'admin')->whereNotNull('organization_id')->first();
        $manager = User::where('role', 'manager')->where('organization_id', $user?->organization_id)->first();
        $executive = User::where('role', 'executive')->where('organization_id', $user?->organization_id)->first();

        if (! $user || ! $user->organization_id) {
            $this->command?->warn('No user with organization found. Please register/login first.');
            return;
        }

        $driver = DB::connection()->getDriverName();

        if ($driver === 'mysql') {
            DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        }

        if (Schema::hasTable('quotations')) {
            DB::table('quotations')->truncate();
        }

        Lead::truncate();

        if (Schema::hasTable('travel_requests')) {
            TravelRequest::truncate();
        }

        if ($driver === 'mysql') {
            DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        }

        $assignees = collect([$executive?->id, $manager?->id, $user->id])->filter()->values();

        $leads = [
            ['Aarav Sharma', 'aarav.sharma@example.com', '9876543210', 'Goa', 20, 4, 2, 2, 0, '4 Star', 45000, 'Website', 'New', 'Couple trip. Wants beach resort and relaxed itinerary.'],
            ['Priya Mehta', 'priya.mehta@example.com', '9811122233', 'Kerala', 35, 6, 4, 2, 2, '3 Star', 85000, 'Instagram', 'Contacted', 'Family vacation. Wants Munnar, Thekkady and Alleppey houseboat.'],
            ['Rohit Kapoor', 'rohit.kapoor@example.com', '9898989898', 'Dubai', 45, 5, 3, 2, 1, '5 Star', 220000, 'Referral', 'Qualified', 'Wants flights, visa, hotel, Burj Khalifa and desert safari.'],
            ['Neha Bansal', 'neha.bansal@example.com', '9955443322', 'Bali', 60, 7, 2, 2, 0, 'Luxury', 180000, 'Website', 'Quotation Sent', 'Honeymoon enquiry. Wants private pool villa and candle light dinner.'],
            ['Vikram Singh', 'vikram.singh@example.com', '9000011111', 'Rajasthan', 18, 5, 6, 4, 2, '4 Star', 120000, 'WhatsApp', 'Won', 'Family heritage trip. Jaipur, Jodhpur and Udaipur preferred.'],
            ['Ananya Rao', 'ananya.rao@example.com', '9123456780', 'Thailand', 75, 6, 2, 2, 0, '3 Star', 95000, 'Facebook', 'Lost', 'Budget-sensitive enquiry. Bangkok and Phuket.'],
            ['Kabir Malhotra', 'kabir.m@example.com', '9345678901', 'Singapore', 30, 5, 4, 2, 2, '4 Star', 160000, 'Call', 'Qualified', 'Family wants Universal Studios and Sentosa.'],
            ['Ishita Arora', 'ishita@example.com', '9234567890', 'Maldives', 52, 4, 2, 2, 0, 'Luxury', 260000, 'Website', 'New', 'Anniversary trip. Wants water villa options.'],
        ];

        foreach ($leads as $index => $lead) {
            Lead::create([
                'organization_id' => $user->organization_id,
                'assigned_to' => $assignees[$index % $assignees->count()] ?? $user->id,
                'customer_name' => $lead[0],
                'email' => $lead[1],
                'phone' => $lead[2],
                'destination' => $lead[3],
                'travel_date' => now()->addDays($lead[4])->toDateString(),
                'duration_days' => $lead[5],
                'travellers' => $lead[6],
                'adults' => $lead[7],
                'children' => $lead[8],
                'hotel_category' => $lead[9],
                'budget' => $lead[10],
                'source' => $lead[11],
                'status' => $lead[12],
                'notes' => $lead[13],
            ]);
        }

        if (Schema::hasTable('travel_requests')) {
            foreach ([
                ['Meera Iyer', 'Kerala', 'Bangalore', 4, 110000, '4 Star', 'Wants family-friendly route and houseboat.'],
                ['Aditya Jain', 'Dubai', 'Delhi', 2, 180000, '5 Star', 'Interested in visa, flights and premium hotel.'],
                ['Sanya Gupta', 'Bali', 'Mumbai', 2, 210000, 'Luxury', 'Honeymoon lead. Private pool villa preferred.'],
                ['Harsh Vohra', 'Goa', 'Delhi', 6, 90000, '3 Star', 'Friends group. Beachside stay and nightlife.'],
            ] as $request) {
                TravelRequest::create([
                    'customer_name' => $request[0],
                    'email' => strtolower(str_replace(' ', '.', $request[0])) . '@example.com',
                    'phone' => '90000' . random_int(10000, 99999),
                    'destination' => $request[1],
                    'departure_city' => $request[2],
                    'travel_month' => now()->addMonth()->format('F Y'),
                    'selected_plan' => 'AI Recommended Plan',
                    'duration_days' => 5,
                    'travellers' => $request[3],
                    'adults' => max(1, min($request[3], 2)),
                    'children' => max(0, $request[3] - 2),
                    'budget' => $request[4],
                    'hotel_category' => $request[5],
                    'notes' => $request[6],
                    'status' => 'New Request',
                    'ai_summary' => $request[6],
                    'ai_draft_plan' => 'Day-wise itinerary can be generated here after AI integration.',
                ]);
            }
        }
    }
}
