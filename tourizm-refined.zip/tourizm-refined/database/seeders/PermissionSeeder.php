<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Permission;

class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [

        // Marketplace
['module' => 'Marketplace', 'name' => 'view_marketplace', 'display_name' => 'View Marketplace'],
['module' => 'Marketplace', 'name' => 'claim_travel_requests', 'display_name' => 'Claim Travel Requests'],

            // Leads
            
            ['module' => 'Leads', 'name' => 'view_leads', 'display_name' => 'View Leads'],
            ['module' => 'Leads', 'name' => 'create_leads', 'display_name' => 'Create Leads'],
            ['module' => 'Leads', 'name' => 'edit_leads', 'display_name' => 'Edit Leads'],
            ['module' => 'Leads', 'name' => 'delete_leads', 'display_name' => 'Delete Leads'],
            ['module' => 'Leads', 'name' => 'assign_leads', 'display_name' => 'Assign Leads'],

            // Customers
            ['module' => 'Customers', 'name' => 'view_customers', 'display_name' => 'View Customers'],
            ['module' => 'Customers', 'name' => 'create_customers', 'display_name' => 'Create Customers'],
            ['module' => 'Customers', 'name' => 'edit_customers', 'display_name' => 'Edit Customers'],
            ['module' => 'Customers', 'name' => 'delete_customers', 'display_name' => 'Delete Customers'],

            // Quotations
            ['module' => 'Quotations', 'name' => 'view_quotations', 'display_name' => 'View Quotations'],
            ['module' => 'Quotations', 'name' => 'create_quotations', 'display_name' => 'Create Quotations'],
            ['module' => 'Quotations', 'name' => 'edit_quotations', 'display_name' => 'Edit Quotations'],
            ['module' => 'Quotations', 'name' => 'send_quotations', 'display_name' => 'Send Quotations'],
            ['module' => 'Quotations', 'name' => 'approve_quotations', 'display_name' => 'Approve Quotations'],

            // Accounts
            ['module' => 'Accounts', 'name' => 'view_accounts', 'display_name' => 'View Accounts'],
            ['module' => 'Accounts', 'name' => 'record_payments', 'display_name' => 'Record Payments'],

            // Procurement
            ['module' => 'Procurement', 'name' => 'view_procurement', 'display_name' => 'View Procurement'],
            ['module' => 'Procurement', 'name' => 'create_vendor_requests', 'display_name' => 'Create Vendor Requests'],
            ['module' => 'Procurement', 'name' => 'confirm_bookings', 'display_name' => 'Confirm Bookings'],

            // Operations
            ['module' => 'Operations', 'name' => 'view_operations', 'display_name' => 'View Operations'],
            ['module' => 'Operations', 'name' => 'generate_vouchers', 'display_name' => 'Generate Vouchers'],
            ['module' => 'Operations', 'name' => 'send_vouchers', 'display_name' => 'Send Vouchers'],

            // Team
            ['module' => 'Team', 'name' => 'view_team', 'display_name' => 'View Team'],
            ['module' => 'Team', 'name' => 'manage_team', 'display_name' => 'Manage Team'],

            // Reports
            ['module' => 'Reports', 'name' => 'view_reports', 'display_name' => 'View Reports'],
            ['module' => 'Reports', 'name' => 'export_reports', 'display_name' => 'Export Reports'],

            // Settings
            ['module' => 'Settings', 'name' => 'manage_settings', 'display_name' => 'Manage Settings'],
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate(
                ['name' => $permission['name']],
                $permission
            );
        }
    }
}
