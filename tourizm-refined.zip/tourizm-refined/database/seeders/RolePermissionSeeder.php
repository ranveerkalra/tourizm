<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Permission;
use Illuminate\Support\Facades\DB;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        // Remove existing mappings
        DB::table('role_permissions')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Admin
        |--------------------------------------------------------------------------
        | Admin gets every permission
        |--------------------------------------------------------------------------
        */

        $adminPermissions = Permission::pluck('id');

        foreach ($adminPermissions as $permissionId) {
            DB::table('role_permissions')->insert([
                'role' => 'admin',
                'permission_id' => $permissionId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Manager
        |--------------------------------------------------------------------------
        */

        $managerPermissions = Permission::whereIn('name', [

            // Leads
            'view_leads',
            'create_leads',
            'edit_leads',
            'assign_leads',

            // Customers
            'view_customers',
            'create_customers',
            'edit_customers',

            // Quotations
            'view_quotations',
            'create_quotations',
            'edit_quotations',
            'send_quotations',
            'approve_quotations',

            // Team
            'view_team',

            // Reports
            'view_reports',

        ])->pluck('id');

        foreach ($managerPermissions as $permissionId) {
            DB::table('role_permissions')->insert([
                'role' => 'manager',
                'permission_id' => $permissionId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Executive
        |--------------------------------------------------------------------------
        */

        $executivePermissions = Permission::whereIn('name', [

            'view_leads',
            'create_leads',
            'edit_leads',

            'view_customers',

            'view_quotations',
            'create_quotations',
            'edit_quotations',
            'send_quotations',

        ])->pluck('id');

        foreach ($executivePermissions as $permissionId) {
            DB::table('role_permissions')->insert([
                'role' => 'executive',
                'permission_id' => $permissionId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
