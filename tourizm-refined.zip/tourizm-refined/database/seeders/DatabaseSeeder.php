<?php

namespace Database\Seeders;

use App\Models\Organization;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        $this->call([
            PermissionSeeder::class,
            RolePermissionSeeder::class,
        ]);

        $organization = Organization::firstOrCreate(
            ['slug' => 'demo-travels'],
            [
                'name' => 'Demo Travels',
                'type' => 'travel_agency',
                'email' => 'admin@demo.test',
                'phone' => '9999999999',
                'status' => 'active',
            ]
        );

        User::firstOrCreate(
            ['email' => 'admin@demo.test'],
            [
                'organization_id' => $organization->id,
                'name' => 'Agency Admin',
                'phone' => '9999999999',
                'employee_code' => 'EMP-0001',
                'role' => 'admin',
                'department' => 'Management',
                'designation' => 'Owner',
                'status' => 'Active',
                'password' => Hash::make('password'),
            ]
        );

        User::firstOrCreate(
            ['email' => 'manager@demo.test'],
            [
                'organization_id' => $organization->id,
                'name' => 'Sales Manager',
                'phone' => '8888888888',
                'employee_code' => 'EMP-0002',
                'role' => 'manager',
                'department' => 'Sales',
                'designation' => 'Sales Manager',
                'status' => 'Active',
                'password' => Hash::make('password'),
            ]
        );

        User::firstOrCreate(
            ['email' => 'executive@demo.test'],
            [
                'organization_id' => $organization->id,
                'name' => 'Travel Executive',
                'phone' => '7777777777',
                'employee_code' => 'EMP-0003',
                'role' => 'executive',
                'department' => 'Sales',
                'designation' => 'Travel Consultant',
                'status' => 'Active',
                'password' => Hash::make('password'),
            ]
        );

        $this->call(LeadSeeder::class);
    }
}
