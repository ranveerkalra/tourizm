<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TravelRequest extends Model
{
    protected $fillable = [
        'customer_name',
        'email',
        'phone',
        'destination',
        'departure_city',
        'travel_date',
        'travel_month',
        'selected_plan',
        'duration_days',
        'travellers',
        'adults',
        'children',
        'budget',
        'hotel_category',
        'notes',
        'missing_details',
        'ai_summary',
        'ai_draft_plan',
        'status',
        'claimed_by_organization_id',
        'converted_lead_id',
        'claimed_at',
        'converted_at',
    ];

    protected $casts = [
        'travel_date' => 'date',
        'budget' => 'decimal:2',
        'claimed_at' => 'datetime',
        'converted_at' => 'datetime',
    ];

    public function claimedByOrganization(): BelongsTo
    {
        return $this->belongsTo(Organization::class, 'claimed_by_organization_id');
    }

    public function convertedLead(): BelongsTo
    {
        return $this->belongsTo(Lead::class, 'converted_lead_id');
    }
}
