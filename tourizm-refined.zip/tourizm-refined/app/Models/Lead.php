<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\Quotation;

class Lead extends Model
{
    use HasFactory;

    protected $fillable = [
    'organization_id',
    'assigned_to',

    'customer_name',
    'email',
    'phone',

    'destination',
    'travel_date',
    'duration_days',
    'travellers',
    'adults',
    'children',
    'hotel_category',
    'budget',

    'source',
    'status',
    'notes',
];

protected $casts = [
    'travel_date' => 'date',
    'duration_days' => 'integer',
    'travellers' => 'integer',
    'adults' => 'integer',
    'children' => 'integer',
    'budget' => 'decimal:2',
];

    public function organization()
    {
        return $this->belongsTo(Organization::class);
    }

    public function assignedUser()
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function quotations()
    {
        return $this->hasMany(Quotation::class);
    }

    public function latestQuotation()
    {
        return $this->hasOne(Quotation::class)->latestOfMany();
    }
}
