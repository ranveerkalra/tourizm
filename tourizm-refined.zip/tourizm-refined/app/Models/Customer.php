<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Customer extends Model
{
   protected $fillable = [
    'organization_id',

    'first_name',
    'last_name',

    'email',
    'phone',

    'address',
    'city',
    'state',
    'country',
    'postal_code',

    'notes',
];

    public function organization()
    {
        return $this->belongsTo(Organization::class);
    }

    public function getFullNameAttribute(): string
    {
        return trim($this->first_name . ' ' . $this->last_name);
    }

    public function quotations(): HasMany
{
    return $this->hasMany(Quotation::class);
}
}
