<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Quotation extends Model
{
    use HasFactory;



public const STATUS_DRAFT = 'draft';
public const STATUS_SENT = 'sent';
public const STATUS_ACCEPTED = 'accepted';
public const STATUS_REJECTED = 'rejected';
public const STATUS_EXPIRED = 'expired';

public const STATUSES = [
    self::STATUS_DRAFT,
    self::STATUS_SENT,
    self::STATUS_ACCEPTED,
    self::STATUS_REJECTED,
    self::STATUS_EXPIRED,
];

public function canBeSent(): bool
{
    return $this->status === self::STATUS_DRAFT;
}

public function canBeAccepted(): bool
{
    return $this->status === self::STATUS_SENT;
}

public function canBeRejected(): bool
{
    return $this->status === self::STATUS_SENT;
}

public function canBeExpired(): bool
{
    return in_array($this->status, [
        self::STATUS_DRAFT,
        self::STATUS_SENT,
    ], true);
}

public function isFinalStatus(): bool
{
    return in_array($this->status, [
        self::STATUS_ACCEPTED,
        self::STATUS_REJECTED,
        self::STATUS_EXPIRED,
    ], true);
}

public function statusLabel(): string
{
    return match ($this->status) {
        self::STATUS_DRAFT => 'Draft',
        self::STATUS_SENT => 'Sent',
        self::STATUS_ACCEPTED => 'Accepted',
        self::STATUS_REJECTED => 'Rejected',
        self::STATUS_EXPIRED => 'Expired',
        default => ucfirst((string) $this->status),
    };
}

public function statusBadgeClass(): string
{
    return match ($this->status) {
        self::STATUS_DRAFT => 'bg-gray-100 text-gray-700',
        self::STATUS_SENT => 'bg-blue-100 text-blue-700',
        self::STATUS_ACCEPTED => 'bg-green-100 text-green-700',
        self::STATUS_REJECTED => 'bg-red-100 text-red-700',
        self::STATUS_EXPIRED => 'bg-yellow-100 text-yellow-700',
        default => 'bg-gray-100 text-gray-700',
    };
}

    protected $fillable = [
    'organization_id',
    'customer_id',
    'lead_id',
    'created_by',

    'quotation_number',
    'title',
    'destination',

    'travel_start_date',
    'travel_end_date',
    'duration_days',

    'travellers',
    'adults',
    'children',
    'hotel_category',

    'subtotal',
    'discount',
    'tax',
    'total_amount',
    'currency',

    'status',
    'valid_until',

    'notes',
    'itinerary_summary',
    'inclusions',
    'exclusions',
    'terms',
];

    protected $casts = [
    'travel_start_date' => 'date',
    'travel_end_date' => 'date',
    'valid_until' => 'date',

    'duration_days' => 'integer',
    'travellers' => 'integer',
    'adults' => 'integer',
    'children' => 'integer',

    'subtotal' => 'decimal:2',
    'discount' => 'decimal:2',
    'tax' => 'decimal:2',
    'total_amount' => 'decimal:2',
];

    public static function statuses(): array
    {
        return self::STATUSES;
    }

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function lead(): BelongsTo
    {
        return $this->belongsTo(Lead::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
