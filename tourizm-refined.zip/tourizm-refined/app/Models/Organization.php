<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Customer;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Organization extends Model
{
    use HasFactory;

    protected $fillable = [
    'name',
    'slug',
    'type',
    'email',
    'phone',
    'status',
];

public function customers()
{
    return $this->hasMany(Customer::class);
}

public function users()
    {
        return $this->hasMany(User::class);
    }

    public function leads()
{
    return $this->hasMany(Lead::class);
}
public function quotations(): HasMany
{
    return $this->hasMany(Quotation::class);
}
}
