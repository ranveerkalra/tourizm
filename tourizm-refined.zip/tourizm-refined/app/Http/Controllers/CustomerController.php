<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\StoreCustomerRequest;
use App\Http\Requests\UpdateCustomerRequest;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;


class CustomerController extends Controller
{
    use AuthorizesRequests;
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
{
    $this->authorize('viewAny', Customer::class);

    $organization = Auth::user()->organization;

    $search = $request->input('search');
    $city = $request->input('city');
    $country = $request->input('country');

    $query = Customer::where('organization_id', $organization->id);

    if (!empty($search)) {
        $query->where(function ($q) use ($search) {
            $q->where('first_name', 'like', "%{$search}%")
              ->orWhere('last_name', 'like', "%{$search}%")
              ->orWhere('email', 'like', "%{$search}%")
              ->orWhere('phone', 'like', "%{$search}%")
              ->orWhere('city', 'like', "%{$search}%")
              ->orWhere('country', 'like', "%{$search}%");
        });
    }

    if (!empty($city)) {
        $query->where('city', $city);
    }

    if (!empty($country)) {
        $query->where('country', $country);
    }

    $cities = Customer::where('organization_id', $organization->id)
        ->whereNotNull('city')
        ->where('city', '!=', '')
        ->distinct()
        ->orderBy('city')
        ->pluck('city');

    $countries = Customer::where('organization_id', $organization->id)
        ->whereNotNull('country')
        ->where('country', '!=', '')
        ->distinct()
        ->orderBy('country')
        ->pluck('country');

    $customers = $query
        ->latest()
        ->paginate(10)
        ->withQueryString();

    return view('customers.index', compact(
        'customers',
        'search',
        'city',
        'country',
        'cities',
        'countries'
    ));
}

    /**
     * Show the form for creating a new resource.
     */
   public function create()
{
    $this->authorize('create', Customer::class);

    return view('customers.create');
}

public function store(StoreCustomerRequest $request)
{
    $this->authorize('create', Customer::class);

    Customer::create([
        'organization_id' => Auth::user()->organization_id,
        ...$request->validated(),
    ]);

    return redirect()
        ->route('customers.index')
        ->with('success', 'Customer created successfully.');
}

    /**
     * Display the specified resource.
     */
    public function show(Customer $customer)
{
    $this->authorize('view', $customer);

    return view('customers.show', compact('customer'));
}

    /**
     * Show the form for editing the specified resource.
     */
public function edit(Customer $customer)
{
    $this->authorize('update', $customer);

    return view('customers.edit', compact('customer'));
}

public function update(UpdateCustomerRequest $request, Customer $customer)
{
    $this->authorize('update', $customer);

    $customer->update($request->validated());

    return redirect()
        ->route('customers.show', $customer)
        ->with('success', 'Customer updated successfully.');
}
    /**
     * Remove the specified resource from storage.
     */
   public function destroy(Customer $customer)
{
    $this->authorize('delete', $customer);

    $customer->delete();

    return redirect()
        ->route('customers.index')
        ->with('success', 'Customer deleted successfully.');
}
}
