<?php

namespace App\Http\Controllers;

use App\Models\Permission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;

class PermissionController extends Controller
{
    public function index()
    {
        // Use Gate to check ability instead of calling undefined hasPermission method
        abort_unless(Auth::user()?->role === 'admin', 403);

        $permissions = Permission::orderBy('module')
            ->orderBy('display_name')
            ->get()
            ->groupBy('module');

        $roles = [
            'admin' => 'Admin',
            'manager' => 'Manager',
            'executive' => 'Executive',
        ];

        $rolePermissions = DB::table('role_permissions')
            ->get()
            ->groupBy('role')
            ->map(fn ($items) => $items->pluck('permission_id')->toArray());

        return view('permissions.index', compact(
            'permissions',
            'roles',
            'rolePermissions'
        ));
    }

    public function updateRole(Request $request, string $role)
    {
        // Ensure current user is admin
        abort_unless(Auth::user()?->role === 'admin', 403);

        $permissionIds = $request->input('permissions', []);

        DB::table('role_permissions')
            ->where('role', $role)
            ->delete();

        foreach ($permissionIds as $permissionId) {
            DB::table('role_permissions')->insert([
                'role' => $role,
                'permission_id' => $permissionId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return redirect()
            ->route('permissions.index')
            ->with('success', ucfirst($role) . ' permissions updated successfully.');
    }
}
