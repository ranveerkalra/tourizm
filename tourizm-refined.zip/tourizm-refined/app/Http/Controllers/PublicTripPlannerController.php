<?php

namespace App\Http\Controllers;

use App\Models\TravelRequest;
use Illuminate\Http\Request;

class PublicTripPlannerController extends Controller
{
    public function index()
    {
        return view('public.trip-planner.index');
    }

    public function search(Request $request)
    {
        $validated = $request->validate([
            'destination' => ['required', 'string', 'max:255'],
        ]);

        $destination = $validated['destination'];

        // Temporary AI-style generated plans.
        // Later this will be replaced with real AI generation.
        $plans = $this->generateTripIdeas($destination);

        return view('public.trip-planner.results', compact('destination', 'plans'));
    }

    public function quote(string $destination, string $plan)
    {
        $plans = $this->generateTripIdeas($destination);

        $selectedPlan = collect($plans)->firstWhere('slug', $plan);

        if (! $selectedPlan) {
            abort(404);
        }

        return view('public.trip-planner.quote', [
            'destination' => $destination,
            'selectedPlan' => $selectedPlan,
        ]);
    }

    public function store(Request $request)
{
    $validated = $request->validate([
        'customer_name' => ['required', 'string', 'max:255'],
        'phone' => ['required', 'string', 'max:30'],
        'email' => ['nullable', 'email', 'max:255'],
        'destination' => ['required', 'string', 'max:255'],
        'departure_city' => ['nullable', 'string', 'max:255'],
        'travel_date' => ['nullable', 'date'],
        'travellers' => ['required', 'integer', 'min:1'],
        'hotel_category' => ['required', 'string', 'in:Budget,3 Star,4 Star,Luxury'],
        'selected_plan' => ['required', 'string', 'max:255'],
        'notes' => ['nullable', 'string'],
    ]);

    TravelRequest::create([
        'customer_name' => $validated['customer_name'],
        'email' => $validated['email'] ?? null,
        'phone' => $validated['phone'],
        'destination' => $validated['destination'],
        'departure_city' => $validated['departure_city'] ?? null,
        'travel_date' => $validated['travel_date'] ?? null,
        'selected_plan' => $validated['selected_plan'],
        'duration_days' => $this->extractDurationDays($validated['selected_plan']),
        'travellers' => $validated['travellers'],
        'hotel_category' => $validated['hotel_category'],
        'notes' => $validated['notes'] ?? null,
        'missing_details' => $this->prepareMissingDetails($validated),
        'ai_summary' => $this->prepareAiSummary($validated),
        'status' => 'Available',
    ]);

    return redirect()
        ->route('trip-planner.index')
        ->with('success', 'Thank you! Your travel request has been submitted to the marketplace. A suitable travel agency will contact you shortly.');
}

private function extractDurationDays(string $selectedPlan): ?int
{
    if (preg_match('/(\d+)\s*Days?/i', $selectedPlan, $matches)) {
        return (int) $matches[1];
    }

    return null;
}

private function prepareMissingDetails(array $data): string
{
    $missing = [];

    if (empty($data['departure_city'])) {
        $missing[] = 'Departure city not provided';
    }

    if (empty($data['travel_date'])) {
        $missing[] = 'Travel date not confirmed';
    }

    $missing[] = 'Adult / child split not confirmed';
    $missing[] = 'Hotel category not confirmed';
    $missing[] = 'Meal plan not confirmed';
    $missing[] = 'Flight / train preference not confirmed';

    return implode("\n", $missing);
}

private function prepareAiSummary(array $data): string
{
    return collect([
        'Public AI Trip Planner request',
        'Destination: ' . $data['destination'],
        'Selected Plan: ' . $data['selected_plan'],
        'Departure City: ' . ($data['departure_city'] ?? 'Not provided'),
        'Travellers: ' . $data['travellers'],
        'Hotel Preference: ' . ($data['hotel_category'] ?? 'Not provided'),
        'Notes: ' . ($data['notes'] ?? 'No special notes'),
    ])->implode("\n");
}
    private function generateTripIdeas(string $destination): array
    {
        return [
            [
                'slug' => '3-days-2-nights',
                'title' => '3 Days / 2 Nights',
                'route' => $destination . ' Short Escape',
                'price' => 18999,
                'highlights' => 'Quick trip, sightseeing, comfortable stay',
                'description' => 'Ideal for a short and refreshing getaway.',
            ],
            [
                'slug' => '4-days-3-nights',
                'title' => '4 Days / 3 Nights',
                'route' => $destination . ' Classic Experience',
                'price' => 24999,
                'highlights' => 'Balanced itinerary, local experiences, relaxed travel',
                'description' => 'Perfect mix of sightseeing, comfort, and relaxation.',
            ],
            [
                'slug' => '5-days-4-nights',
                'title' => '5 Days / 4 Nights',
                'route' => $destination . ' Complete Holiday',
                'price' => 32999,
                'highlights' => 'Best route, premium experience, more free time',
                'description' => 'Experience the best of the destination with a complete plan.',
            ],
        ];
    }


}
