<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTeamMemberRequest;
use App\Http\Requests\UpdateTeamMemberRequest;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class TeamMemberController extends Controller
{
    private function redirectUnauthorized(string $message = 'You are not authorized to access Team.')
    {
        $user = Auth::user();

        if ($user && method_exists($user, 'homeRoute')) {
            return redirect()
                ->route($user->homeRoute())
                ->with('error', $message);
        }

        if ($user && method_exists($user, 'isManager') && $user->isManager()) {
            return redirect()
                ->route('marketplace.travel-requests.index')
                ->with('error', $message);
        }

        if ($user && method_exists($user, 'isExecutive') && $user->isExecutive()) {
            return redirect()
                ->route('leads.index')
                ->with('error', $message);
        }

        return redirect()
            ->route('dashboard')
            ->with('error', $message);
    }

    private function canViewTeam(): bool
    {
        $user = Auth::user();

        return $user && (
            (method_exists($user, 'isAdmin') && $user->isAdmin()) ||
            (method_exists($user, 'hasPermission') && $user->hasPermission('view_team'))
        );
    }

    private function canManageTeam(): bool
    {
        $user = Auth::user();

        return $user && (
            (method_exists($user, 'isAdmin') && $user->isAdmin()) ||
            (method_exists($user, 'hasPermission') && $user->hasPermission('manage_team'))
        );
    }

    public function index()
    {
        if (! $this->canViewTeam()) {
            return $this->redirectUnauthorized();
        }

        $user = Auth::user();

        $teamMembers = User::where('organization_id', $user->organization_id)
            ->latest()
            ->paginate(10);

        return view('team-members.index', compact('teamMembers'));
    }

    public function create()
    {
        if (! $this->canManageTeam()) {
            return $this->redirectUnauthorized('You are not authorized to create team members.');
        }

        return view('team-members.create', [
            'teamMember' => new User(),
        ]);
    }

    public function store(StoreTeamMemberRequest $request)
    {
        if (! $this->canManageTeam()) {
            return $this->redirectUnauthorized('You are not authorized to create team members.');
        }

        $latestUser = User::where('organization_id', Auth::user()->organization_id)
            ->whereNotNull('employee_code')
            ->latest('id')
            ->first();

        $nextNumber = $latestUser
            ? ((int) str_replace('EMP-', '', $latestUser->employee_code)) + 1
            : 1;

        $employeeCode = 'EMP-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

        User::create([
            ...$request->validated(),
            'employee_code' => $employeeCode,
            'organization_id' => Auth::user()->organization_id,
            'password' => Hash::make($request->password),
        ]);

        return redirect()
            ->route('team-members.index')
            ->with('success', 'Team member created successfully.');
    }

    public function edit(User $team_member)
    {
        if (! $this->canManageTeam()) {
            return $this->redirectUnauthorized('You are not authorized to edit team members.');
        }

        if ($team_member->organization_id !== Auth::user()->organization_id) {
            return $this->redirectUnauthorized('You are not authorized to access this team member.');
        }

        return view('team-members.edit', [
            'teamMember' => $team_member,
        ]);
    }

    public function update(UpdateTeamMemberRequest $request, User $team_member)
    {
        if (! $this->canManageTeam()) {
            return $this->redirectUnauthorized('You are not authorized to update team members.');
        }

        if ($team_member->organization_id !== Auth::user()->organization_id) {
            return $this->redirectUnauthorized('You are not authorized to access this team member.');
        }

        $data = $request->validated();

        if (filled($request->password)) {
            $data['password'] = Hash::make($request->password);
        } else {
            unset($data['password']);
        }

        $team_member->update($data);

        return redirect()
            ->route('team-members.index')
            ->with('success', 'Team member updated successfully.');
    }

    public function destroy(User $team_member)
    {
        if (! $this->canManageTeam()) {
            return $this->redirectUnauthorized('You are not authorized to deactivate team members.');
        }

        if ($team_member->organization_id !== Auth::user()->organization_id) {
            return $this->redirectUnauthorized('You are not authorized to access this team member.');
        }

        $team_member->update([
            'status' => 'Inactive',
        ]);

        return redirect()
            ->route('team-members.index')
            ->with('success', 'Team member deactivated successfully.');
    }
}

