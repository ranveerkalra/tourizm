<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreLeadRequest;
use App\Http\Requests\UpdateLeadRequest;
use App\Models\Lead;
use App\Models\User;
use Illuminate\Http\Request;

class LeadController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        if (! $user) {
            return redirect()->route('login');
        }

        $organizationId = $user->organization_id;
        $search = $request->input('search');
        $status = $request->input('status');

        $leadsQuery = Lead::with(['latestQuotation', 'assignedUser'])
            ->where('organization_id', $organizationId);

        if ($user->role === 'executive') {
            $leadsQuery->where('assigned_to', $user->id);
        }

        if ($search) {
            $leadsQuery->where(function ($query) use ($search) {
                $query->where('customer_name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%")
                    ->orWhere('phone', 'like', "%{$search}%")
                    ->orWhere('destination', 'like', "%{$search}%");
            });
        }

        if ($status) {
            $leadsQuery->where('status', $status);
        }

        $hasTeam = User::where('organization_id', $organizationId)
    ->where('id', '!=', $user->id)
    ->whereIn('role', ['manager', 'executive'])
    ->exists();
        $leads = $leadsQuery->latest()->paginate(10)->withQueryString();

        $stats = [
            'total' => Lead::where('organization_id', $organizationId)->count(),
            'new' => Lead::where('organization_id', $organizationId)->where('status', 'New')->count(),
            'contacted' => Lead::where('organization_id', $organizationId)->where('status', 'Contacted')->count(),
            'qualified' => Lead::where('organization_id', $organizationId)->where('status', 'Qualified')->count(),
            'quotation_sent' => Lead::where('organization_id', $organizationId)->where('status', 'Quotation Sent')->count(),
            'won' => Lead::where('organization_id', $organizationId)->where('status', 'Won')->count(),
            'lost' => Lead::where('organization_id', $organizationId)->where('status', 'Lost')->count(),
        ];

        return view('leads.index', compact('leads', 'search', 'status', 'stats', 'hasTeam'));
    }

    public function create()
    {
        $this->authorize('create', Lead::class);

        return view('leads.create', [
            'lead' => new Lead(),
        ]);
    }

    public function store(StoreLeadRequest $request)
    {
        $this->authorize('create', Lead::class);

        $user = $request->user();
        $data = $request->validated();

        $data['organization_id'] = $user->organization_id;
        $data['assigned_to'] = null;
        $data['status'] = 'New';

        Lead::create($data);

        return redirect()
            ->route('leads.index')
            ->with('success', 'Lead created successfully.');
    }

    public function show(Lead $lead)
    {
        $this->authorize('view', $lead);

        $lead->load(['latestQuotation', 'assignedUser']);

        return view('leads.show', compact('lead'));
    }

    public function edit(Lead $lead)
    {
        $this->authorize('update', $lead);

        return view('leads.edit', compact('lead'));
    }

    public function update(UpdateLeadRequest $request, Lead $lead)
    {
        $this->authorize('update', $lead);

        $data = $request->validated();

        unset($data['organization_id'], $data['assigned_to'], $data['status']);

        $lead->update($data);

        return redirect()
            ->route('leads.show', $lead)
            ->with('success', 'Lead updated successfully.');
    }

    public function destroy(Lead $lead)
    {
        $this->authorize('delete', $lead);

        $lead->delete();

        return redirect()
            ->route('leads.index')
            ->with('success', 'Lead deleted successfully.');
    }

    public function assign(Request $request, Lead $lead)
    {
        $this->authorize('assign', $lead);

        $consultants = User::where('organization_id', $request->user()->organization_id)
            ->whereIn('role', ['executive', 'manager'])
            ->orderBy('name')
            ->get();

        return view('leads.assign', compact('lead', 'consultants'));
    }

    public function updateAssignment(Request $request, Lead $lead)
    {
        $this->authorize('assign', $lead);

        $validated = $request->validate([
            'assigned_to' => ['required', 'exists:users,id'],
        ]);

        $assignedUser = User::where('id', $validated['assigned_to'])
            ->where('organization_id', $request->user()->organization_id)
            ->whereIn('role', ['executive', 'manager'])
            ->firstOrFail();

     $lead->update([
    'assigned_to' => $assignedUser->id,
]);

return redirect()
    ->route('leads.index');
}
}
