<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Organization;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): View
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws ValidationException
     */
  public function store(Request $request): RedirectResponse
{
    $request->validate([
        'organization_name' => ['required', 'string', 'max:255'],
        'owner_name' => ['required', 'string', 'max:255'],
        'email'             => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:users,email'],
        'phone'             => ['required', 'string', 'max:20'],
        'password'          => ['required', 'confirmed', Rules\Password::defaults()],
    ]);

   $organization = Organization::create([
    'name'   => $request->organization_name,
    'slug'   => Str::slug($request->organization_name) . '-' . Str::lower(Str::random(5)),
    'type'   => 'travel_agency',
    'email'  => $request->email,
    'phone'  => $request->phone,
    'status' => 'active',
]);

$user = User::create([
    'organization_id' => $organization->id,
    'name'            => $request->owner_name,
    'email'           => $request->email,
    'phone'           => $request->phone,
    'password'        => Hash::make($request->password),
    'role'            => 'admin',
    'department'      => 'Management',
    'designation'     => 'Owner',
    'status'          => 'Active',
]);

event(new Registered($user));

Auth::login($user);

return redirect()->route('dashboard');

}
}
