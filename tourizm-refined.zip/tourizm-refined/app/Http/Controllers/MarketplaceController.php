<?php

namespace App\Http\Controllers;

use App\Models\TravelRequest;
use App\Models\Lead;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class MarketplaceController extends Controller
{
    public function index()
{
     abort_unless(Auth::check() && Auth::user()->hasPermission('view_marketplace'), 403);
    $travelRequests = TravelRequest::query()
        ->whereIn('status', ['Available', 'Claimed'])
        ->latest()
        ->paginate(10);

    return view('marketplace.travel-requests.index', compact('travelRequests'));
}
    public function show(TravelRequest $travelRequest)
{
    return view('marketplace.travel-requests.show', compact('travelRequest'));
}

public function claim(TravelRequest $travelRequest)
{
   abort_unless(auth()->user()->hasPermission('claim_travel_requests'), 403);
    if ($travelRequest->status !== 'Available') {
        return redirect()
            ->route('marketplace.travel-requests.index')
            ->with('error', 'This travel request is no longer available.');
    }

    $user = Auth::user();

    $lead = Lead::create([
    'organization_id' => $user->organization_id,
    'assigned_to' => $user->id,
    'customer_name' => $travelRequest->customer_name,
    'email' => $travelRequest->email,
    'phone' => $travelRequest->phone,
    'destination' => $travelRequest->destination,
    'travel_date' => $travelRequest->travel_date,
    'duration_days' => $travelRequest->duration_days,
    'travellers' => $travelRequest->travellers,
    'hotel_category' => $travelRequest->hotel_category,
    'budget' => null,
    'source' => 'Website',
    'status' => 'New',
    'notes' => collect([
        'Created from Marketplace Travel Request',
        'Request ID: TR-' . str_pad($travelRequest->id, 6, '0', STR_PAD_LEFT),
        'Selected Plan: ' . ($travelRequest->selected_plan ?? 'Not selected'),
        'Hotel Preference: ' . ($travelRequest->hotel_category ?? 'Not selected'),
        'Departure City: ' . ($travelRequest->departure_city ?? 'Not provided'),
        'Missing Details:',
        $travelRequest->missing_details ?? 'No missing details recorded.',
        'AI Summary:',
        $travelRequest->ai_summary ?? 'No AI summary recorded.',
        'Customer Notes:',
        $travelRequest->notes ?? 'No customer notes.',
    ])->implode("\n"),
]);

    $travelRequest->update([
    'status' => 'Claimed',
    'claimed_by_organization_id' => $user->organization_id,
    'converted_lead_id' => $lead->id,
    'claimed_at' => now(),
    'converted_at' => now(),
]);

return redirect()
    ->route('marketplace.travel-requests.index')
    ->with('success', 'Travel request claimed successfully. Lead has been created.');
}

}
