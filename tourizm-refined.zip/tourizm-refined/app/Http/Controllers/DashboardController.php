<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use App\Models\TravelRequest;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $organizationId = $user?->organization_id;
        $filter = request('filter', 'this_year');

        if (! in_array($filter, ['today', 'last_7_days', 'this_month', 'this_year', 'all_time'], true)) {
            $filter = 'this_year';
        }

        $baseQuery = Lead::query()->where('organization_id', $organizationId);

        match ($filter) {
            'today' => $baseQuery->whereDate('created_at', today()),
            'last_7_days' => $baseQuery->where('created_at', '>=', now()->subDays(7)->startOfDay()),
            'this_month' => $baseQuery->whereYear('created_at', now()->year)->whereMonth('created_at', now()->month),
            'this_year' => $baseQuery->whereYear('created_at', now()->year),
            default => null,
        };

        $totalLeads = (clone $baseQuery)->count();
        $newLeads = (clone $baseQuery)->where('status', 'New')->count();
        $qualifiedLeads = (clone $baseQuery)->where('status', 'Qualified')->count();
        $bookedTrips = (clone $baseQuery)->where('status', 'Won')->count();
        $lostLeads = (clone $baseQuery)->where('status', 'Lost')->count();
        $unassignedLeads = (clone $baseQuery)->whereNull('assigned_to')->count();
        $pipelineValue = (clone $baseQuery)->whereNotIn('status', ['Won', 'Lost'])->sum('budget');
        $averageBudget = (clone $baseQuery)->whereNotNull('budget')->avg('budget') ?? 0;
        $conversionRate = $totalLeads > 0 ? round(($bookedTrips / $totalLeads) * 100, 1) : 0;

        $statusCounts = (clone $baseQuery)
            ->selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        $leadStatuses = [
            'New' => ['label' => 'New', 'bar' => 'bg-blue-500'],
            'Contacted' => ['label' => 'Contacted', 'bar' => 'bg-cyan-500'],
            'Qualified' => ['label' => 'Qualified', 'bar' => 'bg-amber-500'],
            'Quotation Sent' => ['label' => 'Quotation Sent', 'bar' => 'bg-violet-500'],
            'Won' => ['label' => 'Won', 'bar' => 'bg-emerald-500'],
            'Lost' => ['label' => 'Lost', 'bar' => 'bg-rose-500'],
        ];

        $statusDistribution = collect($leadStatuses)->map(function ($meta, $status) use ($statusCounts, $totalLeads) {
            $count = $statusCounts[$status] ?? 0;

            return [
                'label' => $meta['label'],
                'count' => $count,
                'bar' => $meta['bar'],
                'percentage' => $totalLeads > 0 ? round(($count / $totalLeads) * 100) : 0,
            ];
        })->values();

        $monthlyQuery = Lead::query()->where('organization_id', $organizationId);

        if ($filter !== 'all_time') {
            $monthlyQuery->whereYear('created_at', now()->year);
        }

        $monthlyLeads = $monthlyQuery
            ->selectRaw('MONTH(created_at) as month, COUNT(*) as total')
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        $leadCounts = array_fill(0, 12, 0);

        foreach ($monthlyLeads as $lead) {
            $leadCounts[$lead->month - 1] = (int) $lead->total;
        }

        $sourceCounts = (clone $baseQuery)
            ->selectRaw('source, COUNT(*) as total')
            ->groupBy('source')
            ->orderByDesc('total')
            ->limit(6)
            ->get();

        $sourceLabels = $sourceCounts->pluck('source')->values();
        $sourceData = $sourceCounts->pluck('total')->map(fn ($value) => (int) $value)->values();

        $recentLeads = (clone $baseQuery)
            ->with('assignedUser')
            ->latest()
            ->take(6)
            ->get();

        $upcomingTrips = Lead::query()
            ->where('organization_id', $organizationId)
            ->whereNotIn('status', ['Lost'])
            ->whereDate('travel_date', '>=', today())
            ->orderBy('travel_date')
            ->take(5)
            ->get();

        $marketplaceRequests = TravelRequest::query()
            ->whereNull('claimed_by_organization_id')
            ->latest()
            ->take(4)
            ->get();

        return view('dashboard', compact(
            'filter',
            'totalLeads',
            'newLeads',
            'qualifiedLeads',
            'bookedTrips',
            'lostLeads',
            'unassignedLeads',
            'pipelineValue',
            'averageBudget',
            'conversionRate',
            'statusDistribution',
            'recentLeads',
            'upcomingTrips',
            'marketplaceRequests',
            'months',
            'leadCounts',
            'sourceLabels',
            'sourceData'
        ));
    }
}
