<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreQuotationRequest;
use App\Http\Requests\UpdateQuotationRequest;
use App\Models\Customer;
use App\Models\Lead;
use App\Models\Quotation;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class QuotationController extends Controller
{
    use AuthorizesRequests;

    /**
     * Display a listing of quotations.
     */
    public function index(): View
    {
        $this->authorize('viewAny', Quotation::class);

        $user = Auth::user();

        $query = Quotation::query()
            ->with(['customer', 'lead', 'creator'])
            ->where('organization_id', $user->organization_id);

        if (request()->filled('search')) {
            $search = request('search');

            $query->where(function ($q) use ($search) {
                $q->where('quotation_number', 'like', "%{$search}%")
                    ->orWhere('title', 'like', "%{$search}%")
                    ->orWhere('destination', 'like', "%{$search}%")
                    ->orWhereHas('customer', function ($customerQuery) use ($search) {
    $customerQuery->where('email', 'like', "%{$search}%")
        ->orWhere('phone', 'like', "%{$search}%");
});
            });
        }

        if (request()->filled('status') && in_array(request('status'), Quotation::statuses(), true)) {
            $query->where('status', request('status'));
        }

        $quotations = $query
            ->latest()
            ->paginate(10)
            ->withQueryString();

        return view('quotations.index', compact('quotations'));
    }

    /**
     * Show the form for creating a new quotation.
     */
   public function create(Request $request): View
{
    $this->authorize('create', Quotation::class);

    $user = $request->user();

    $selectedLead = null;

    if ($request->filled('lead_id')) {
        $selectedLead = Lead::where('organization_id', $user->organization_id)
            ->findOrFail($request->query('lead_id'));
    }

    $customers = Customer::where('organization_id', $user->organization_id)
        ->get()
        ->sortBy('full_name')
        ->values();

    $leads = Lead::where('organization_id', $user->organization_id)
        ->latest()
        ->get();

    $statuses = Quotation::statuses();

    return view('quotations.create', [
        'quotation' => new Quotation(),
        'customers' => $customers,
        'leads' => $leads,
        'statuses' => $statuses,
        'selectedLead' => $selectedLead,
    ]);
}

    /**
     * Store a newly created quotation.
     */
    public function store(StoreQuotationRequest $request): RedirectResponse
{
    $this->authorize('create', Quotation::class);

    $user = Auth::user();

    $validated = $this->prepareQuotationData($request->validated());

    $lead = null;

    if (! empty($validated['lead_id'])) {
        $lead = Lead::where('organization_id', $user->organization_id)
            ->findOrFail($validated['lead_id']);
    }

    if (! empty($validated['customer_id'])) {
        $customer = Customer::where('organization_id', $user->organization_id)
            ->findOrFail($validated['customer_id']);

        $validated['customer_id'] = $customer->id;
    } elseif ($lead) {
        $customer = $this->findOrCreateCustomerFromLead($lead, $user->organization_id);

        $validated['customer_id'] = $customer->id;
    } else {
        abort(422, 'Please select a customer or linked lead.');
    }

    $validated['organization_id'] = $user->organization_id;
    $validated['created_by'] = $user->id;
    $validated['quotation_number'] = $this->generateQuotationNumber();

    // New workflow: Send Offer directly
    $validated['status'] = Quotation::STATUS_SENT;

    $quotation = Quotation::create($validated);

    if ($quotation->lead) {
        $quotation->lead->update([
            'status' => 'Quotation Sent',
        ]);
    }

    return redirect()
        ->route('quotations.show', $quotation)
        ->with('success', 'Quotation sent successfully.');
}

/**
 * Display the specified quotation.
 */
public function show(Quotation $quotation): View
{
    $this->authorize('view', $quotation);

    $quotation->load(['customer', 'lead', 'creator']);

    return view('quotations.show', compact('quotation'));
}
    /**
     * Show the form for editing the specified quotation.
     */
    public function edit(Quotation $quotation): View
    {
        $this->authorize('update', $quotation);

        $user = Auth::user();

    $customers = Customer::where('organization_id', $user->organization_id)
    ->get()
    ->sortBy('full_name')
    ->values();

        $leads = Lead::query()
            ->where('organization_id', $user->organization_id)
            ->latest()
            ->get();

        $statuses = Quotation::statuses();

        return view('quotations.edit', compact('quotation', 'customers', 'leads', 'statuses'));
    }

    /**
     * Update the specified quotation.
     */
    public function update(UpdateQuotationRequest $request, Quotation $quotation): RedirectResponse
{
    $this->authorize('update', $quotation);

    $user = Auth::user();

    $validated = $this->prepareQuotationData($request->validated());

    $lead = null;

    if (! empty($validated['lead_id'])) {
        $lead = Lead::where('organization_id', $user->organization_id)
            ->findOrFail($validated['lead_id']);
    }

    if (! empty($validated['customer_id'])) {
        Customer::where('organization_id', $user->organization_id)
            ->findOrFail($validated['customer_id']);
    } elseif ($lead) {
        $customer = $this->findOrCreateCustomerFromLead($lead, $user->organization_id);
        $validated['customer_id'] = $customer->id;
    } else {
        abort(422, 'Please select a customer or linked lead.');
    }

    $quotation->update($validated);

    return redirect()
        ->route('quotations.show', $quotation)
        ->with('success', 'Quotation updated successfully.');
}

    /**
     * Remove the specified quotation.
     */
    public function destroy(Quotation $quotation): RedirectResponse
    {
        $this->authorize('delete', $quotation);

        $quotation->delete();

        return redirect()
            ->route('quotations.index')
            ->with('success', 'Quotation deleted successfully.');
    }

    /**
     * Prepare quotation financial values before saving.
     */
    private function prepareQuotationData(array $validated): array
{
    $subtotal = (float) ($validated['subtotal'] ?? 0);
    $discount = (float) ($validated['discount'] ?? 0);
    $tax = (float) ($validated['tax'] ?? 0);

    $adults = $validated['adults'] ?? null;
    $children = $validated['children'] ?? null;

    // Link to lead is optional
    $validated['lead_id'] = $validated['lead_id'] ?? null;

    // Safe defaults
    $validated['discount'] = $discount;
    $validated['tax'] = $tax;
    $validated['currency'] = $validated['currency'] ?? 'INR';
    $validated['status'] = $validated['status'] ?? Quotation::STATUS_DRAFT;

    // If adults/children are provided, calculate total travellers automatically
    if ($adults !== null || $children !== null) {
        $validated['travellers'] = (int) ($adults ?? 0) + (int) ($children ?? 0);
    } else {
        $validated['travellers'] = $validated['travellers'] ?? 1;
    }

    // If start date + duration are provided but end date is empty, calculate end date
    if (
        ! empty($validated['travel_start_date']) &&
        ! empty($validated['duration_days']) &&
        empty($validated['travel_end_date'])
    ) {
        $validated['travel_end_date'] = \Carbon\Carbon::parse($validated['travel_start_date'])
            ->addDays((int) $validated['duration_days'] - 1)
            ->toDateString();
    }

    // Final amount is system calculated, not trusted from form input
    $validated['total_amount'] = max($subtotal - $discount + $tax, 0);

    return $validated;
}

    /**
     * Generate a unique quotation number.
     */
    private function generateQuotationNumber(): string
    {
        return 'QTN-' . now()->format('YmdHis') . '-' . Str::upper(Str::random(4));
    }
    public function send(Quotation $quotation): RedirectResponse
{
    Gate::authorize('update', $quotation);

    if (! $quotation->canBeSent()) {
        return back()->with('error', 'Only draft quotations can be sent.');
    }

    $quotation->update([
        'status' => Quotation::STATUS_SENT,
    ]);

    return redirect()
        ->route('quotations.show', $quotation)
        ->with('success', 'Quotation marked as sent.');
}

public function accept(Quotation $quotation): RedirectResponse
{
    Gate::authorize('update', $quotation);

    if (! $quotation->canBeAccepted()) {
        return back()->with('error', 'Only sent quotations can be accepted.');
    }

    $quotation->update([
        'status' => Quotation::STATUS_ACCEPTED,
    ]);

    return redirect()
        ->route('quotations.show', $quotation)
        ->with('success', 'Quotation accepted successfully.');
}

public function reject(Quotation $quotation): RedirectResponse
{
    Gate::authorize('update', $quotation);

    if (! $quotation->canBeRejected()) {
        return back()->with('error', 'Only sent quotations can be rejected.');
    }

    $quotation->update([
        'status' => Quotation::STATUS_REJECTED,
    ]);

    return redirect()
        ->route('quotations.show', $quotation)
        ->with('success', 'Quotation rejected successfully.');
}

public function expire(Quotation $quotation): RedirectResponse
{
    Gate::authorize('update', $quotation);

    if (! $quotation->canBeExpired()) {
        return back()->with('error', 'Only draft or sent quotations can be expired.');
    }

    $quotation->update([
        'status' => Quotation::STATUS_EXPIRED,
    ]);

    return redirect()
        ->route('quotations.show', $quotation)
        ->with('success', 'Quotation marked as expired.');
}
private function findOrCreateCustomerFromLead(Lead $lead, int $organizationId): Customer
{
    $nameParts = preg_split('/\s+/', trim($lead->customer_name), 2);

    $customerData = [
        'organization_id' => $organizationId,
        'first_name' => $nameParts[0] ?? $lead->customer_name,
        'last_name' => $nameParts[1] ?? null,
        'email' => $lead->email,
        'phone' => $lead->phone,
        'notes' => 'Synced from lead #' . $lead->id . ' while creating quotation.',
    ];

    if ($lead->phone) {
        return Customer::updateOrCreate(
            [
                'organization_id' => $organizationId,
                'phone' => $lead->phone,
            ],
            $customerData
        );
    }

    if ($lead->email) {
        return Customer::updateOrCreate(
            [
                'organization_id' => $organizationId,
                'email' => $lead->email,
            ],
            $customerData
        );
    }

    return Customer::create($customerData);
}
}
