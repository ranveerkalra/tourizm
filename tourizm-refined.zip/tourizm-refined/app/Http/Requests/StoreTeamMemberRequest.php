<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class StoreTeamMemberRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],

            'email' => [
                'required',
                'email',
                'max:255',
                'unique:users,email',
            ],

            'phone' => ['required', 'string', 'max:20'],

            'role' => [
    'required',
    'string',
    'in:admin,manager,executive',
],

'department' => [
    'required',
    'string',
    'in:Sales,Accounts,Procurement,Operations,Support,Management',
],

'designation' => [
    'required',
    'string',
    'max:255',
],

            'status' => [
                'required',
                'string',
                'in:Active,Inactive,Suspended',
            ],

            'password' => [
                'required',
                'confirmed',
                Password::defaults(),
            ],
        ];
    }
}
