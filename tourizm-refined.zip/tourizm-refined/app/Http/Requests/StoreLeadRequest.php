<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class StoreLeadRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
{
    return true;
}

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
   public function rules(): array
{
    return [
        'customer_name' => ['required', 'string', 'max:255'],
        'phone' => ['required', 'string', 'max:30'],
        'destination' => ['required', 'string', 'max:255'],

        'email' => ['nullable', 'email', 'max:255'],
        'travel_date' => ['nullable', 'date'],
        'duration_days' => ['nullable', 'integer', 'min:1', 'max:365'],
        'travellers' => ['nullable', 'integer', 'min:1', 'max:100'],
        'adults' => ['nullable', 'integer', 'min:0', 'max:100'],
        'children' => ['nullable', 'integer', 'min:0', 'max:100'],
        'hotel_category' => ['nullable', 'string', 'max:100'],
        'budget' => ['nullable', 'numeric', 'min:0'],
        'source' => ['nullable', 'string', 'max:100'],
        'status' => ['nullable', 'string', 'max:50'],
        'notes' => ['nullable', 'string', 'max:5000'],
    ];
}
}
