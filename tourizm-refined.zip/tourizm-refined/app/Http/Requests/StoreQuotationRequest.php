<?php

namespace App\Http\Requests;

use App\Models\Quotation;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreQuotationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
{
    return [
        'customer_id' => ['nullable', 'required_without:lead_id', 'integer', 'exists:customers,id'],
        'lead_id' => ['nullable', 'integer', 'exists:leads,id'],

        'title' => ['required', 'string', 'max:255'],
        'destination' => ['required', 'string', 'max:255'],

        'travel_start_date' => ['nullable', 'date'],
        'travel_end_date' => ['nullable', 'date', 'after_or_equal:travel_start_date'],
        'duration_days' => ['nullable', 'integer', 'min:1', 'max:365'],

        'travellers' => ['nullable', 'integer', 'min:1', 'max:100'],
        'adults' => ['nullable', 'integer', 'min:0', 'max:100'],
        'children' => ['nullable', 'integer', 'min:0', 'max:100'],
        'hotel_category' => ['nullable', 'string', 'max:100'],

        'subtotal' => ['required', 'numeric', 'min:0'],
        'discount' => ['nullable', 'numeric', 'min:0'],
        'tax' => ['nullable', 'numeric', 'min:0'],
        'currency' => ['required', 'string', 'max:10'],

        'status' => ['nullable', Rule::in(Quotation::statuses())],
        'valid_until' => ['nullable', 'date'],

        'notes' => ['nullable', 'string', 'max:5000'],
        'itinerary_summary' => ['nullable', 'string', 'max:10000'],
        'inclusions' => ['nullable', 'string', 'max:10000'],
        'exclusions' => ['nullable', 'string', 'max:10000'],
        'terms' => ['nullable', 'string', 'max:10000'],
    ];
}
}
