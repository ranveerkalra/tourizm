<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreCustomerRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'first_name' => ['required', 'string', 'max:255'],
            'last_name'  => ['nullable', 'string', 'max:255'],
            'email'      => ['nullable', 'email', 'max:255'],
            'phone'      => ['required', 'string', 'max:20'],
            'city'       => ['nullable', 'string', 'max:255'],
            'country'    => ['nullable', 'string', 'max:255'],
            'notes'      => ['nullable', 'string'],
        ];
    }
}
