<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;

class UpdateTeamMemberRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    public function rules(): array
    {
        return [

            'name' => [
                'required',
                'string',
                'max:255',
            ],

            'email' => [
                'required',
                'email',
                'max:255',
                Rule::unique('users')->ignore($this->team_member),
            ],

            'phone' => [
                'required',
                'string',
                'max:20',
            ],

            'role' => [
                'required',
                'in:admin,manager,executive',
            ],

            'department' => [
                'required',
                'in:Sales,Accounts,Procurement,Operations,Support,Management',
            ],

            'designation' => [
                'required',
                'string',
                'max:255',
            ],

            'status' => [
                'required',
                'in:Active,Inactive,Suspended',
            ],

            // Password is OPTIONAL while editing
            'password' => [
                'nullable',
                'confirmed',
                Password::defaults(),
            ],

        ];
    }
}
