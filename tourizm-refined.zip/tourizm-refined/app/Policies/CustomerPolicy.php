<?php

namespace App\Policies;

use App\Models\Customer;
use App\Models\User;

class CustomerPolicy
{
    /**
     * Any authenticated user can view the customer list.
     */
    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * Users can only view customers belonging to their organization.
     */
    public function view(User $user, Customer $customer): bool
    {
        return $user->organization_id === $customer->organization_id;
    }

    /**
     * Any authenticated user can create customers.
     */
    public function create(User $user): bool
    {
        return true;
    }

    /**
     * Users can only update customers in their organization.
     */
    public function update(User $user, Customer $customer): bool
    {
        return $user->organization_id === $customer->organization_id;
    }

    /**
     * Users can only delete customers in their organization.
     */
    public function delete(User $user, Customer $customer): bool
    {
        return $user->organization_id === $customer->organization_id;
    }

    public function restore(User $user, Customer $customer): bool
    {
        return false;
    }

    public function forceDelete(User $user, Customer $customer): bool
    {
        return false;
    }

}
