<?php

namespace App\Policies;

use App\Models\Quotation;
use App\Models\User;

class QuotationPolicy
{
    /**
     * Determine whether the user can view any quotations.
     */
    public function viewAny(User $user): bool
    {
        return $user->organization_id !== null;
    }

    /**
     * Determine whether the user can view the quotation.
     */
    public function view(User $user, Quotation $quotation): bool
    {
        return $user->organization_id === $quotation->organization_id;
    }

    /**
     * Determine whether the user can create quotations.
     */
    public function create(User $user): bool
    {
        return $user->organization_id !== null;
    }

    /**
     * Determine whether the user can update the quotation.
     */
    public function update(User $user, Quotation $quotation): bool
    {
        return $user->organization_id === $quotation->organization_id;
    }

    /**
     * Determine whether the user can delete the quotation.
     */
    public function delete(User $user, Quotation $quotation): bool
    {
        return $user->organization_id === $quotation->organization_id;
    }

    /**
     * Determine whether the user can restore the quotation.
     */
    public function restore(User $user, Quotation $quotation): bool
    {
        return $user->organization_id === $quotation->organization_id;
    }

    /**
     * Determine whether the user can permanently delete the quotation.
     */
    public function forceDelete(User $user, Quotation $quotation): bool
    {
        return $user->organization_id === $quotation->organization_id;
    }
}
