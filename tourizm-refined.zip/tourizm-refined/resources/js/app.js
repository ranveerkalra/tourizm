import Alpine from 'alpinejs';
import { Chart, LineController, LineElement, PointElement, BarController, BarElement, CategoryScale, LinearScale, Tooltip, Legend, Filler } from 'chart.js';

Chart.register(LineController, LineElement, PointElement, BarController, BarElement, CategoryScale, LinearScale, Tooltip, Legend, Filler);

window.Alpine = Alpine;
window.Chart = Chart;

function parseDataset(element, key) {
    try {
        return JSON.parse(element.dataset[key] || '[]');
    } catch (error) {
        return [];
    }
}

function bootDashboardCharts() {
    const monthlyChart = document.getElementById('monthlyLeadsChart');

    if (monthlyChart) {
        const labels = parseDataset(monthlyChart, 'labels');
        const values = parseDataset(monthlyChart, 'values');

        new Chart(monthlyChart, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: 'Leads',
                    data: values,
                    borderWidth: 3,
                    tension: 0.35,
                    fill: true,
                    pointRadius: 4,
                    pointHoverRadius: 6,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { intersect: false, mode: 'index' },
                },
                scales: {
                    x: { grid: { display: false } },
                    y: { beginAtZero: true, ticks: { precision: 0 } },
                },
            },
        });
    }

    const sourceChart = document.getElementById('sourceLeadsChart');

    if (sourceChart) {
        const labels = parseDataset(sourceChart, 'labels');
        const values = parseDataset(sourceChart, 'values');

        new Chart(sourceChart, {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: 'Leads',
                    data: values,
                    borderWidth: 0,
                    borderRadius: 12,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { intersect: false, mode: 'index' },
                },
                scales: {
                    x: { grid: { display: false } },
                    y: { beginAtZero: true, ticks: { precision: 0 } },
                },
            },
        });
    }
}

document.addEventListener('DOMContentLoaded', bootDashboardCharts);

Alpine.start();
