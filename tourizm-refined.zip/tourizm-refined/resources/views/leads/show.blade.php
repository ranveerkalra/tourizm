<x-app-layout>
    <x-slot name="header">
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                Lead Details
            </h2>
            <p class="mt-1 text-sm text-gray-500">
                View customer enquiry, travel plan and lead actions.
            </p>
        </div>

        <div class="w-full sm:w-[360px]">
            {{-- Top row actions --}}
            <div class="grid grid-cols-3 gap-2">
                <a href="{{ route('leads.edit', $lead) }}"
                   class="inline-flex items-center justify-center rounded-md bg-yellow-500 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-yellow-600">
                    Edit
                </a>

                <form action="{{ route('leads.destroy', $lead) }}"
                      method="POST"
                      onsubmit="return confirm('Are you sure you want to delete this lead?');">
                    @csrf
                    @method('DELETE')

                    <button type="submit"
                            class="inline-flex w-full items-center justify-center rounded-md bg-red-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-red-700">
                        Delete
                    </button>
                </form>

                <a href="{{ route('leads.index') }}"
                   class="inline-flex items-center justify-center rounded-md bg-gray-700 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-800">
                    ← Back
                </a>
            </div>

            {{-- Full width offer action --}}
            <a href="{{ route('quotations.create', ['lead_id' => $lead->id]) }}"
               class="mt-2 inline-flex w-full items-center justify-center rounded-md border border-green-200 bg-green-50 px-4 py-2 text-sm font-semibold text-green-700 shadow-sm hover:bg-green-100">
                Create Offer
            </a>
        </div>
    </div>
</x-slot>

    @php
        $statusClasses = match ($lead->status) {
            'New' => 'bg-blue-100 text-blue-700',
            'Contacted' => 'bg-purple-100 text-purple-700',
            'Qualified' => 'bg-green-100 text-green-700',
            'Quotation Sent' => 'bg-indigo-100 text-indigo-700',
            'Won' => 'bg-emerald-100 text-emerald-700',
            'Lost' => 'bg-red-100 text-red-700',
            default => 'bg-gray-100 text-gray-700',
        };

        $adults = $lead->adults ?? null;
        $children = $lead->children ?? null;

        $totalTravellers = ($adults !== null || $children !== null)
            ? ((int) ($adults ?? 0) + (int) ($children ?? 0))
            : ($lead->travellers ?? null);
    @endphp

    <div class="py-8">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-6 rounded-md border border-green-200 bg-green-50 px-4 py-3 text-sm font-medium text-green-700">
                    {{ session('success') }}
                </div>
            @endif

            {{-- Summary Card --}}
            <div class="mb-6 overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-200">
                <div class="border-b border-gray-100 px-6 py-5">
                    <div class="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                        <div>
                            <h3 class="text-2xl font-bold text-gray-900">
                                {{ $lead->customer_name }}
                            </h3>

                            <div class="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-500">
                                <span>{{ $lead->phone ?? 'No phone' }}</span>
                                <span>{{ $lead->email ?? 'No email' }}</span>
                            </div>
                        </div>

                        <div class="flex flex-wrap gap-2">
                            <span class="inline-flex rounded-full px-3 py-1 text-xs font-semibold {{ $statusClasses }}">
                                {{ $lead->status }}
                            </span>

                            <span class="inline-flex rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-700">
                                {{ $lead->source ?? 'No Source' }}
                            </span>
                        </div>
                    </div>
                </div>

                <div class="grid gap-0 md:grid-cols-3">
                    <div class="border-b border-gray-100 px-6 py-5 md:border-b-0 md:border-r">
                        <p class="text-xs font-medium uppercase tracking-wide text-gray-500">Destination</p>
                        <p class="mt-1 text-lg font-semibold text-gray-900">
                            {{ $lead->destination ?? '—' }}
                        </p>
                    </div>

                    <div class="border-b border-gray-100 px-6 py-5 md:border-b-0 md:border-r">
                        <p class="text-xs font-medium uppercase tracking-wide text-gray-500">Travel Date</p>
                        <p class="mt-1 text-lg font-semibold text-gray-900">
                            {{ $lead->travel_date ? \Carbon\Carbon::parse($lead->travel_date)->format('d M Y') : '—' }}
                        </p>
                    </div>

                    <div class="px-6 py-5">
                        <p class="text-xs font-medium uppercase tracking-wide text-gray-500">Budget</p>
                        <p class="mt-1 text-lg font-semibold text-gray-900">
                            {{ $lead->budget ? '₹' . number_format((float) $lead->budget) : '—' }}
                        </p>
                    </div>
                </div>
            </div>

            <div class="grid gap-6 lg:grid-cols-2">

                {{-- Customer Details --}}
                <div class="rounded-xl bg-white p-6 shadow-sm ring-1 ring-gray-200">
                    <h3 class="mb-5 text-lg font-semibold text-gray-900">
                        Customer Details
                    </h3>

                    <dl class="space-y-4">
                        <div class="flex justify-between gap-6 border-b border-gray-100 pb-3">
                            <dt class="text-sm text-gray-500">Customer Name</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $lead->customer_name }}
                            </dd>
                        </div>

                        <div class="flex justify-between gap-6 border-b border-gray-100 pb-3">
                            <dt class="text-sm text-gray-500">Phone / WhatsApp</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $lead->phone ?? '—' }}
                            </dd>
                        </div>

                        <div class="flex justify-between gap-6 border-b border-gray-100 pb-3">
                            <dt class="text-sm text-gray-500">Email</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $lead->email ?? '—' }}
                            </dd>
                        </div>

                        <div class="flex justify-between gap-6">
                            <dt class="text-sm text-gray-500">Lead Source</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $lead->source ?? '—' }}
                            </dd>
                        </div>
                    </dl>
                </div>

                {{-- Travel Enquiry --}}
                <div class="rounded-xl bg-white p-6 shadow-sm ring-1 ring-gray-200">
                    <h3 class="mb-5 text-lg font-semibold text-gray-900">
                        Travel Enquiry
                    </h3>

                    <dl class="space-y-4">
                        <div class="flex justify-between gap-6 border-b border-gray-100 pb-3">
                            <dt class="text-sm text-gray-500">Destination</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $lead->destination ?? '—' }}
                            </dd>
                        </div>

                        <div class="flex justify-between gap-6 border-b border-gray-100 pb-3">
                            <dt class="text-sm text-gray-500">Travel Date</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $lead->travel_date ? \Carbon\Carbon::parse($lead->travel_date)->format('d M Y') : '—' }}
                            </dd>
                        </div>

                        <div class="flex justify-between gap-6 border-b border-gray-100 pb-3">
                            <dt class="text-sm text-gray-500">Duration</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $lead->duration ? $lead->duration . ' day(s)' : '—' }}
                            </dd>
                        </div>

                        <div class="flex justify-between gap-6 border-b border-gray-100 pb-3">
                            <dt class="text-sm text-gray-500">Travellers</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $totalTravellers ?? '—' }}
                            </dd>
                        </div>

                        <div class="flex justify-between gap-6 border-b border-gray-100 pb-3">
                            <dt class="text-sm text-gray-500">Adults</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $lead->adults ?? '—' }}
                            </dd>
                        </div>

                        <div class="flex justify-between gap-6 border-b border-gray-100 pb-3">
                            <dt class="text-sm text-gray-500">Children</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $lead->children ?? '—' }}
                            </dd>
                        </div>

                        <div class="flex justify-between gap-6">
                            <dt class="text-sm text-gray-500">Hotel Category</dt>
                            <dd class="text-right text-sm font-semibold text-gray-900">
                                {{ $lead->hotel_category ?? '—' }}
                            </dd>
                        </div>
                    </dl>
                </div>

            </div>

            {{-- Notes --}}
            <div class="mt-6 rounded-xl bg-white p-6 shadow-sm ring-1 ring-gray-200">
                <h3 class="mb-3 text-lg font-semibold text-gray-900">
                    Notes
                </h3>

                <p class="whitespace-pre-line text-sm leading-6 text-gray-700">
                    {{ $lead->notes ?: 'No notes added for this lead.' }}
                </p>
            </div>

        </div>
    </div>
</x-app-layout>
