<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Assign Lead
        </h2>
    </x-slot>

    <div class="py-6">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg overflow-hidden">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 text-xs uppercase text-gray-600">
                        <tr>
                            <th class="px-4 py-3 text-left">Customer</th>
                            <th class="px-4 py-3 text-left">Destination</th>
                            <th class="px-4 py-3 text-left">Travel Plan</th>
                            <th class="px-4 py-3 text-left">Traveler(s)</th>
                            <th class="px-4 py-3 text-left">Hotel</th>
                            <th class="px-4 py-3 text-left">Status</th>
                            <th class="px-4 py-3 text-center">Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr class="border-t">
                            <td class="px-4 py-4 align-top">
                                <div class="font-semibold text-gray-900">{{ $lead->customer_name }}</div>
                                <div class="text-gray-500">{{ $lead->phone }}</div>
                            </td>

                            <td class="px-4 py-4 align-top">
                                <div class="font-semibold text-gray-900">{{ $lead->destination ?? 'N/A' }}</div>
                                <div class="text-gray-500">{{ $lead->source ?? 'Website' }}</div>
                            </td>

                            <td class="px-4 py-4 align-top">
                                <div class="font-semibold text-gray-900">
                                    {{ $lead->travel_date ? \Carbon\Carbon::parse($lead->travel_date)->format('d M Y') : 'N/A' }}
                                </div>
                                <div class="text-gray-500">
                                    {{ $lead->duration ?? '3 Days / 2 Nights' }}
                                </div>
                            </td>

                            <td class="px-4 py-4 align-top font-semibold text-gray-900">
                                {{ $lead->travelers ?? '2 Travelers' }}
                            </td>

                            <td class="px-4 py-4 align-top">
                                <span class="px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-semibold">
                                    Budget
                                </span>
                            </td>

                            <td class="px-4 py-4 align-top">
                                <span class="px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold">
                                    {{ $lead->status }}
                                </span>
                            </td>

                            <td class="px-4 py-4 align-top">
                               @if ($lead->assigned_to)
    <div class="mx-auto max-w-52 rounded-lg border border-yellow-300 bg-yellow-50 px-4 py-3 text-center">
        <p class="text-[10px] font-semibold text-gray-600">
            Assigned to
        </p>

        <p class="text-xs font-bold text-gray-900">
            {{ $lead->assignedUser?->name ?? 'Unknown User' }}
        </p>
    </div>
@else
    <form method="POST" action="{{ route('leads.updateAssignment', $lead) }}">
        @csrf
        @method('PATCH')

        <select
            name="assigned_to"
            class="w-full rounded-md border-gray-300 text-xs shadow-sm"
            required
        >
            <option value="">Assign to</option>

            @foreach ($consultants as $consultant)
                <option value="{{ $consultant->id }}">
                    {{ $consultant->name }}
                </option>
            @endforeach
        </select>

        <button
            type="submit"
            class="mt-4 w-full rounded-md border border-yellow-400 bg-yellow-50 px-4 py-2 text-sm font-semibold text-yellow-700 hover:bg-yellow-100"
        >
            Assign
        </button>
    </form>
@endif
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-app-layout>
