<x-app-layout>

    <x-slot name="header">
        <h2 class="text-2xl font-bold">
            Edit Lead
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto">

            <div class="bg-white rounded-xl shadow p-8">

                <form method="POST" action="{{ route('leads.update', $lead) }}">

                    @csrf
                    @method('PUT')

                    @include('leads._form', [
                        'buttonText' => 'Update Lead',
                        'showStatus' => true,
                    ])

                </form>

            </div>

        </div>
    </div>

</x-app-layout>
