@csrf

<div class="space-y-8">

    {{-- Basic Customer Details --}}
    <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900">
            Customer Details
        </h3>
        <p class="mt-1 text-sm text-gray-500">
            Capture only the minimum details needed to start the enquiry.
        </p>

        <div class="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
            <div>
                <label for="customer_name" class="block text-sm font-medium text-gray-700">
                    Customer Name <span class="text-red-500">*</span>
                </label>
                <input
                    type="text"
                    name="customer_name"
                    id="customer_name"
                    value="{{ old('customer_name', $lead->customer_name ?? '') }}"
                    required
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('customer_name')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="phone" class="block text-sm font-medium text-gray-700">
                    Phone / WhatsApp <span class="text-red-500">*</span>
                </label>
                <input
                    type="text"
                    name="phone"
                    id="phone"
                    value="{{ old('phone', $lead->phone ?? '') }}"
                    required
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('phone')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="email" class="block text-sm font-medium text-gray-700">
                    Email
                </label>
                <input
                    type="email"
                    name="email"
                    id="email"
                    value="{{ old('email', $lead->email ?? '') }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('email')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="source" class="block text-sm font-medium text-gray-700">
                    Lead Source
                </label>
                <select
                    name="source"
                    id="source"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                    @php
                        $selectedSource = old('source', $lead->source ?? 'Manual');
                    @endphp

                    <option value="Manual" @selected($selectedSource === 'Manual')>Manual</option>
                    <option value="Website" @selected($selectedSource === 'Website')>Website</option>
                    <option value="WhatsApp" @selected($selectedSource === 'WhatsApp')>WhatsApp</option>
                    <option value="Instagram" @selected($selectedSource === 'Instagram')>Instagram</option>
                    <option value="Facebook" @selected($selectedSource === 'Facebook')>Facebook</option>
                    <option value="Referral" @selected($selectedSource === 'Referral')>Referral</option>
                    <option value="Other" @selected($selectedSource === 'Other')>Other</option>
                </select>
                @error('source')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>
        </div>
    </div>

    {{-- Travel Enquiry Details --}}
    <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900">
            Travel Enquiry
        </h3>
        <p class="mt-1 text-sm text-gray-500">
            These details help the agent suggest a ready itinerary quickly.
        </p>

        <div class="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
            <div>
                <label for="destination" class="block text-sm font-medium text-gray-700">
                    Destination <span class="text-red-500">*</span>
                </label>
                <input
                    type="text"
                    name="destination"
                    id="destination"
                    value="{{ old('destination', $lead->destination ?? '') }}"
                    required
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('destination')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="travel_date" class="block text-sm font-medium text-gray-700">
                    Travel Date
                </label>
                <input
                    type="date"
                    name="travel_date"
                    id="travel_date"
                    value="{{ old('travel_date', isset($lead->travel_date) ? $lead->travel_date->format('Y-m-d') : '') }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('travel_date')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="duration_days" class="block text-sm font-medium text-gray-700">
                    Duration / Number of Days
                </label>
                <input
                    type="number"
                    name="duration_days"
                    id="duration_days"
                    min="1"
                    value="{{ old('duration_days', $lead->duration_days ?? '') }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('duration_days')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="hotel_category" class="block text-sm font-medium text-gray-700">
                    Hotel Category
                </label>
                @php
                    $selectedHotelCategory = old('hotel_category', $lead->hotel_category ?? '');
                @endphp
                <select
                    name="hotel_category"
                    id="hotel_category"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                    <option value="">Select hotel category</option>
                    <option value="Budget" @selected($selectedHotelCategory === 'Budget')>Budget</option>
                    <option value="3 Star" @selected($selectedHotelCategory === '3 Star')>3 Star</option>
                    <option value="4 Star" @selected($selectedHotelCategory === '4 Star')>4 Star</option>
                    <option value="5 Star" @selected($selectedHotelCategory === '5 Star')>5 Star</option>
                    <option value="Luxury" @selected($selectedHotelCategory === 'Luxury')>Luxury</option>
                </select>
                @error('hotel_category')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="adults" class="block text-sm font-medium text-gray-700">
                    Adults
                </label>
                <input
                    type="number"
                    name="adults"
                    id="adults"
                    min="0"
                    value="{{ old('adults', $lead->adults ?? '') }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('adults')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="children" class="block text-sm font-medium text-gray-700">
                    Children
                </label>
                <input
                    type="number"
                    name="children"
                    id="children"
                    min="0"
                    value="{{ old('children', $lead->children ?? '') }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('children')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="budget" class="block text-sm font-medium text-gray-700">
                    Budget
                </label>
                <input
                    type="number"
                    name="budget"
                    id="budget"
                    min="0"
                    step="0.01"
                    value="{{ old('budget', $lead->budget ?? '') }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('budget')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>
        </div>

        <div class="mt-6">
            <label for="notes" class="block text-sm font-medium text-gray-700">
                Notes / Requirement
            </label>
            <textarea
                name="notes"
                id="notes"
                rows="4"
                class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="Example: Honeymoon trip, family vacation, wants beach resort, flexible dates..."
            >{{ old('notes', $lead->notes ?? '') }}</textarea>
            @error('notes')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>
    </div>

    {{-- Submit --}}
    <div class="flex items-center justify-end gap-3">
        <a
            href="{{ route('leads.index') }}"
            class="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
        >
            Cancel
        </a>

        <button
            type="submit"
            class="rounded-lg bg-indigo-600 px-5 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700"
        >
            {{ isset($lead) && $lead->exists ? 'Update Lead' : 'Create Lead' }}
        </button>
    </div>
</div>
