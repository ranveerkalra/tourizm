<x-app-layout>

    <x-slot name="header">
        <h2 class="text-2xl font-bold">
            Create New Lead
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto">

            <div class="bg-white rounded-xl shadow p-8">

                <form method="POST" action="{{ route('leads.store') }}">

                    @csrf

                    @include('leads._form', [
                        'buttonText' => 'Save Lead',
                        'showStatus' => false,
                    ])

                </form>

            </div>

        </div>
    </div>

</x-app-layout>
