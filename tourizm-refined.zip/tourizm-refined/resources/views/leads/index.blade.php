<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="text-2xl font-bold text-gray-800">
                Lead Management
            </h2>

            @permission('create_leads')
                <a href="{{ route('leads.create') }}" class="text-sm font-semibold text-gray-900 hover:text-indigo-600">
                    + New Lead
                </a>
            @endpermission
        </div>
    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            @if(session('success'))
                <div class="mb-6 bg-green-100 border border-green-300 text-green-700 px-4 py-3 rounded-lg">
                    {{ session('success') }}
                </div>
            @endif

            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-6">
                <div class="bg-white p-4 rounded-xl shadow">
                    <p class="text-sm text-gray-500">Total</p>
                    <p class="text-2xl font-bold">{{ $stats['total'] }}</p>
                </div>

                <div class="bg-blue-50 p-4 rounded-xl shadow">
                    <p class="text-sm text-blue-600">New</p>
                    <p class="text-2xl font-bold text-blue-700">{{ $stats['new'] }}</p>
                </div>

                <div class="bg-amber-50 p-4 rounded-xl shadow">
                    <p class="text-sm text-amber-600">Contacted</p>
                    <p class="text-2xl font-bold text-amber-700">{{ $stats['contacted'] }}</p>
                </div>

                <div class="bg-purple-50 p-4 rounded-xl shadow">
                    <p class="text-sm text-purple-600">Qualified</p>
                    <p class="text-2xl font-bold text-purple-700">{{ $stats['qualified'] }}</p>
                </div>

                <div class="bg-orange-50 p-4 rounded-xl shadow">
                    <p class="text-sm text-orange-600">Quotation</p>
                    <p class="text-2xl font-bold text-orange-700">{{ $stats['quotation_sent'] }}</p>
                </div>

                <div class="bg-green-50 p-4 rounded-xl shadow">
                    <p class="text-sm text-green-600">Won</p>
                    <p class="text-2xl font-bold text-green-700">{{ $stats['won'] }}</p>
                </div>

                <div class="bg-red-50 p-4 rounded-xl shadow">
                    <p class="text-sm text-red-600">Lost</p>
                    <p class="text-2xl font-bold text-red-700">{{ $stats['lost'] }}</p>
                </div>
            </div>

            <div class="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">

                <div class="border-b border-gray-200 bg-white p-5">
                    <form method="GET" action="{{ route('leads.index') }}">
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-4">
                            <input
                                type="text"
                                name="search"
                                value="{{ $search ?? '' }}"
                                placeholder="Search by customer, email, phone or destination..."
                                class="md:col-span-2 rounded-lg border-gray-300 text-sm focus:border-indigo-500 focus:ring-indigo-500"
                            >

                            <select
                                name="status"
                                class="rounded-lg border-gray-300 text-sm focus:border-indigo-500 focus:ring-indigo-500"
                            >
                                <option value="">All Status</option>
                                <option value="New" {{ ($status ?? '') === 'New' ? 'selected' : '' }}>New</option>
                                <option value="Contacted" {{ ($status ?? '') === 'Contacted' ? 'selected' : '' }}>Contacted</option>
                                <option value="Qualified" {{ ($status ?? '') === 'Qualified' ? 'selected' : '' }}>Qualified</option>
                                <option value="Quotation Sent" {{ ($status ?? '') === 'Quotation Sent' ? 'selected' : '' }}>Quotation Sent</option>
                                <option value="Won" {{ ($status ?? '') === 'Won' ? 'selected' : '' }}>Won</option>
                                <option value="Lost" {{ ($status ?? '') === 'Lost' ? 'selected' : '' }}>Lost</option>
                            </select>

                            <div class="flex gap-3">
                                <button
                                    type="submit"
                                    class="flex-1 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700"
                                >
                                    🔍 Search
                                </button>

                                @if(!empty($search) || !empty($status))
                                    <a
                                        href="{{ route('leads.index') }}"
                                        class="flex-1 rounded-lg border border-gray-300 px-4 py-2 text-center text-sm font-semibold text-gray-700 hover:bg-gray-100"
                                    >
                                        Clear
                                    </a>
                                @endif
                            </div>
                        </div>
                    </form>
                </div>

                @if($leads->count())
                    <div class="border-b border-gray-200 px-4 py-3 text-sm text-gray-500">
                        Showing {{ $leads->firstItem() }}–{{ $leads->lastItem() }} of {{ $leads->total() }} leads
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full table-fixed divide-y divide-gray-200 text-sm">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="w-[150px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Customer</th>
                                    <th class="w-[120px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Destination</th>
                                    <th class="w-[190px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Travel Plan</th>
                                    <th class="w-[120px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Traveler(s)</th>
                                    <th class="w-[90px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Hotel</th>
                                    <th class="w-[95px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Status</th>
                                    <th class="w-[180px] px-3 py-3 text-center text-xs font-bold uppercase tracking-wider text-gray-600">Actions</th>
                                </tr>
                            </thead>

                            <tbody class="divide-y divide-gray-100 bg-white">
                                @foreach($leads as $lead)
                                    @php
                                        $travelDate = $lead->travel_date
                                            ? $lead->travel_date->format('d M Y')
                                            : 'Travel date pending';

                                        $durationLabel = $lead->duration_days
                                            ? $lead->duration_days . ' Days / ' . max($lead->duration_days - 1, 0) . ' Nights'
                                            : 'Duration pending';

                                        $hotelBadge = match($lead->hotel_category) {
                                            'Budget' => 'bg-green-100 text-green-700',
                                            '3 Star' => 'bg-blue-100 text-blue-700',
                                            '4 Star' => 'bg-purple-100 text-purple-700',
                                            'Luxury' => 'bg-yellow-100 text-yellow-800',
                                            default => 'bg-gray-100 text-gray-700',
                                        };

                                        $statusBadge = match($lead->status) {
                                            'New' => 'bg-blue-100 text-blue-700',
                                            'Contacted' => 'bg-amber-100 text-amber-700',
                                            'Qualified' => 'bg-purple-100 text-purple-700',
                                            'Quotation Sent' => 'bg-orange-100 text-orange-700',
                                            'Won' => 'bg-green-100 text-green-700',
                                            'Lost' => 'bg-red-100 text-red-700',
                                            default => 'bg-gray-100 text-gray-700',
                                        };
                                    @endphp

                                    <tr class="hover:bg-gray-50">
                                        <td class="px-3 py-4 align-top">
                                            <div class="text-sm font-semibold text-gray-900">
                                                {{ $lead->customer_name }}
                                            </div>

                                            <div class="mt-1 text-sm text-gray-500">
                                                {{ $lead->phone }}
                                            </div>

                                            @if($lead->email)
                                                <div class="mt-1 truncate text-xs text-gray-400">
                                                    {{ $lead->email }}
                                                </div>
                                            @endif
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <div class="text-sm font-semibold text-gray-900">
                                                {{ ucfirst($lead->destination) }}
                                            </div>

                                            <div class="mt-1 text-xs text-gray-400">
                                                {{ $lead->source ?? 'Manual' }}
                                            </div>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <div class="text-sm font-semibold text-gray-900">
                                                {{ $travelDate }}
                                            </div>

                                            <div class="mt-1 text-xs text-gray-400">
                                                {{ $durationLabel }}
                                            </div>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <div class="whitespace-nowrap text-sm font-semibold text-gray-900">
                                                {{ $lead->travellers ?? 1 }} Travelers
                                            </div>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <span class="inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap {{ $hotelBadge }}">
                                                {{ $lead->hotel_category ?? 'Pending' }}
                                            </span>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <span class="inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap {{ $statusBadge }}">
                                                {{ $lead->status }}
                                            </span>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <div class="flex flex-col space-y-2">
                                                @can('assign', $lead)
                                                    @if($hasTeam)
                                                        @if($lead->assigned_to)
                                                            <a
                                                                href="{{ route('leads.show', $lead) }}"
                                                                class="w-full rounded-lg border border-yellow-300 bg-yellow-50 px-4 py-3 text-center block hover:bg-yellow-100"
                                                            >
                                                                <p class="text-[10px] font-semibold text-gray-600">
                                                                    Assigned to
                                                                </p>

                                                                <p class="text-xs font-bold text-gray-900">
                                                                    {{ $lead->assignedUser?->name ?? 'Unknown User' }}
                                                                </p>
                                                            </a>
                                                        @else
                                                            <a
                                                                href="{{ route('leads.assign', $lead) }}"
                                                                class="w-full rounded-md bg-blue-600 px-4 py-2 text-sm font-semibold text-white text-center block hover:bg-blue-700"
                                                            >
                                                                Assign
                                                            </a>

                                                            <a
                                                                href="{{ route('quotations.create', ['lead_id' => $lead->id]) }}"
                                                                class="w-full rounded-md border border-green-300 bg-green-50 px-4 py-2 text-sm font-semibold text-green-700 text-center block hover:bg-green-100"
                                                            >
                                                                Create Offer
                                                            </a>
                                                        @endif
                                                    @else
                                                        <a
                                                            href="#"
                                                            class="w-full rounded-md border border-green-300 bg-green-50 px-4 py-2 text-sm font-semibold text-green-700 text-center block hover:bg-green-100"
                                                        >
                                                            Create Offer
                                                        </a>
                                                    @endif
                                                @else
                                                    <a href="{{ route('quotations.create') }}"
                                                        class="w-full rounded-md border border-green-300 bg-green-50 px-4 py-2 text-sm font-semibold text-green-700 text-center block hover:bg-green-100"
                                                    >
                                                        Create Offer
                                                    </a>
                                                @endcan
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div class="border-t border-gray-200 px-6 py-4">
                        {{ $leads->links() }}
                    </div>
                @else
                    <div class="p-12 text-center">
                        <div class="text-5xl">🌍</div>

                        <h2 class="mt-4 text-xl font-bold text-gray-900">
                            No Leads Found
                        </h2>

                        <p class="mt-2 text-gray-600">
                            Try another search or create a new lead.
                        </p>

                        @permission('create_leads')
                            <a
                                href="{{ route('leads.create') }}"
                                class="mt-6 inline-flex rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700"
                            >
                                Add New Lead
                            </a>
                        @endpermission
                    </div>
                @endif

            </div>
        </div>
    </div>
</x-app-layout>
