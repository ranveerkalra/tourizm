@props(['disabled' => false])

<input @disabled($disabled) {{ $attributes->merge(['class' => 'rounded-2xl border-slate-200 bg-slate-50 shadow-sm focus:border-cyan-500 focus:ring-cyan-500']) }}>
