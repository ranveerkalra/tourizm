<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Edit Customer
            </h2>

            <a href="{{ route('customers.show', $customer) }}"
               class="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700">
                Back to Customer
            </a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white shadow-sm sm:rounded-lg p-6">

                <form method="POST" action="{{ route('customers.update', $customer) }}">
                    @csrf
                    @method('PUT')

                    @include('customers._form', [
                        'buttonText' => 'Update Customer'
                    ])
                </form>

            </div>

        </div>
    </div>
</x-app-layout>
