<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Customer Management
            </h2>

            <a href="{{ route('customers.create') }}"
               class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700">
                + New Customer
            </a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 rounded-md bg-green-100 border border-green-300 text-green-800 px-4 py-3">
                    {{ session('success') }}
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">

                <form method="GET" action="{{ route('customers.index') }}" class="mb-6">
    <div class="flex flex-wrap gap-3">

        <input
            type="text"
            name="search"
            value="{{ $search ?? '' }}"
            placeholder="Search by name, email, phone, city or country..."
            class="flex-1 min-w-[260px] border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500">

        <select
            name="city"
            class="border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500">

            <option value="">All Cities</option>

            @foreach($cities as $item)
                <option value="{{ $item }}" {{ ($city ?? '') == $item ? 'selected' : '' }}>
                    {{ $item }}
                </option>
            @endforeach

        </select>

        <select
            name="country"
            class="border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500">

            <option value="">All Countries</option>

            @foreach($countries as $item)
                <option value="{{ $item }}" {{ ($country ?? '') == $item ? 'selected' : '' }}>
                    {{ $item }}
                </option>
            @endforeach

        </select>

        <button
            type="submit"
            class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg font-semibold">
            🔍 Search
        </button>

        @if(!empty($search) || !empty($city) || !empty($country))
            <a href="{{ route('customers.index') }}"
               class="bg-gray-600 hover:bg-gray-700 text-white px-5 py-2 rounded-lg font-semibold">
                Clear
            </a>
        @endif

    </div>
</form>

                @if ($customers->count())
                    <div class="overflow-x-auto">
@if($customers->count())
    <div class="px-6 py-4 text-sm text-gray-500 border-b">
        Showing {{ $customers->firstItem() }}–{{ $customers->lastItem() }}
        of {{ $customers->total() }} customers
    </div>
@endif
                        <table class="min-w-full divide-y divide-gray-200">
                           <thead class="bg-gray-100 text-gray-700 uppercase text-xs tracking-wider">
                                <tr>
                                    <th class="text-left px-6 py-4">Customer</th>
<th class="text-left px-6 py-4">Email</th>
<th class="text-left px-6 py-4">Phone</th>
<th class="text-left px-6 py-4">City</th>
<th class="text-left px-6 py-4">Actions</th>
                                </tr>
                            </thead>

                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach ($customers as $customer)
                                    <tr class="odd:bg-white even:bg-gray-50 hover:bg-indigo-50 transition">
                                        <td class="px-6 py-4 font-medium text-gray-900">
                                            {{ $customer->full_name }}
                                        </td>
                                        <td class="px-6 py-4 text-gray-600">
                                            {{ $customer->email ?? '—' }}
                                        </td>
                                        <td class="px-6 py-4 text-gray-600">
                                            {{ $customer->phone }}
                                        </td>
                                        <td class="px-6 py-4 text-gray-600">
                                            {{ $customer->city ?? '—' }}
                                        </td>
                                        <td class="px-6 py-4">
    <div class="flex flex-wrap gap-2">

        <a href="{{ route('customers.show', $customer) }}"
           class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-md text-xs font-semibold">
            View
        </a>

        <a href="{{ route('customers.edit', $customer) }}"
           class="bg-amber-500 hover:bg-amber-600 text-white px-3 py-1.5 rounded-md text-xs font-semibold">
            Edit
        </a>

        <form action="{{ route('customers.destroy', $customer) }}"
              method="POST"
              onsubmit="return confirm('Delete this customer?')">

            @csrf
            @method('DELETE')

            <button
                type="submit"
                class="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-md text-xs font-semibold">
                Delete
            </button>

        </form>

    </div>
</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-6">
                        {{ $customers->links() }}
                    </div>
                @else
                    <div class="text-center py-12">
                        <div class="text-5xl mb-4">👤</div>
                        <h3 class="text-lg font-semibold text-gray-900">No Customers Yet</h3>
                        <p class="mt-2 text-gray-500">Start building your customer database.</p>

                        <a href="{{ route('customers.create') }}"
                           class="mt-4 inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                            Add First Customer
                        </a>
                    </div>
                @endif

            </div>
        </div>
    </div>
</x-app-layout>
