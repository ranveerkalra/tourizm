<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Customer Details
            </h2>

            <a href="{{ route('customers.index') }}"
               class="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700">
                Back to Customers
            </a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

@if (session('success'))
    <div class="mb-4 rounded-md bg-green-100 border border-green-300 px-4 py-3 text-green-800">
        {{ session('success') }}
    </div>
@endif

            <div class="bg-white shadow-sm sm:rounded-lg p-6">

                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h3 class="text-2xl font-bold text-gray-900">
                            {{ $customer->first_name }} {{ $customer->last_name }}
                        </h3>

                        <p class="text-sm text-gray-500 mt-1">
                            Customer since {{ $customer->created_at->format('d M Y') }}
                        </p>
                    </div>

                    <a href="{{ route('customers.edit', $customer) }}"
                       class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                        Edit Customer
                    </a>


                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                    <div>
                        <h4 class="font-semibold text-gray-700 mb-3">
                            Personal Information
                        </h4>

                        <div class="space-y-3">
                            <p><strong>First Name:</strong> {{ $customer->first_name }}</p>
                            <p><strong>Last Name:</strong> {{ $customer->last_name }}</p>
                            <p><strong>Email:</strong> {{ $customer->email ?? 'N/A' }}</p>
                            <p><strong>Phone:</strong> {{ $customer->phone ?? 'N/A' }}</p>
                        </div>
                    </div>

                    <div>
                        <h4 class="font-semibold text-gray-700 mb-3">
                            Address Information
                        </h4>

                        <div class="space-y-3">
                            <p><strong>Address:</strong> {{ $customer->address ?? 'N/A' }}</p>
                            <p><strong>City:</strong> {{ $customer->city ?? 'N/A' }}</p>
                            <p><strong>State:</strong> {{ $customer->state ?? 'N/A' }}</p>
                            <p><strong>Country:</strong> {{ $customer->country ?? 'N/A' }}</p>
                            <p><strong>Postal Code:</strong> {{ $customer->postal_code ?? 'N/A' }}</p>
                        </div>
                    </div>

                </div>

            </div>

        </div>
    </div>
</x-app-layout>
