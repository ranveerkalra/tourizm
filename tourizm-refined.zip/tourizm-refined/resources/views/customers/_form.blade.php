<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <div>
        <label class="block text-sm font-medium text-gray-700">First Name</label>
        <input type="text" name="first_name" value="{{ old('first_name', $customer->first_name ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('first_name') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Last Name</label>
        <input type="text" name="last_name" value="{{ old('last_name', $customer->last_name ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('last_name') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Email</label>
        <input type="email" name="email" value="{{ old('email', $customer->email ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('email') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Phone</label>
        <input type="text" name="phone" value="{{ old('phone', $customer->phone ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('phone') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
    </div>

    <div class="md:col-span-2">
        <label class="block text-sm font-medium text-gray-700">Address</label>
        <input type="text" name="address" value="{{ old('address', $customer->address ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('address') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">City</label>
        <input type="text" name="city" value="{{ old('city', $customer->city ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('city') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">State</label>
        <input type="text" name="state" value="{{ old('state', $customer->state ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('state') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Country</label>
        <input type="text" name="country" value="{{ old('country', $customer->country ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('country') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Postal Code</label>
        <input type="text" name="postal_code" value="{{ old('postal_code', $customer->postal_code ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('postal_code') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
    </div>

    <div class="md:col-span-2">
        <label class="block text-sm font-medium text-gray-700">Notes</label>
        <textarea name="notes" rows="4" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">{{ old('notes', $customer->notes ?? '') }}</textarea>
        @error('notes') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
    </div>
</div>

<div class="mt-6 flex justify-end">
    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
        {{ $buttonText ?? 'Save Customer' }}
    </button>
</div>
