<x-app-layout>
    <div class="px-5 py-6 sm:px-8">
        <div class="mb-6 overflow-hidden rounded-[2rem] bg-slate-950 shadow-2xl shadow-slate-200">
            <div class="relative isolate px-6 py-7 text-white sm:px-8 lg:px-10">
                <div class="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_right,rgba(34,211,238,0.28),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(59,130,246,0.32),transparent_35%)]"></div>
                <div class="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
                    <div class="max-w-3xl">
                        <p class="mb-3 inline-flex rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-xs font-black uppercase tracking-[0.24em] text-cyan-100">Command Center</p>
                        <h1 class="text-3xl font-black tracking-tight sm:text-4xl">Dashboard built for travel agents who need speed.</h1>
                        <p class="mt-3 max-w-2xl text-sm leading-6 text-slate-300 sm:text-base">Track leads, buy fresh travel requests, assign work, follow quotations and see what needs attention before clients go cold.</p>
                    </div>

                    <div class="flex flex-wrap gap-3">
                        <a href="{{ route('leads.create') }}" class="rounded-2xl bg-white px-5 py-3 text-sm font-black text-slate-950 shadow-lg transition hover:bg-cyan-50">+ Add Lead</a>
                        <a href="{{ route('marketplace.travel-requests.index') }}" class="rounded-2xl border border-white/15 bg-white/10 px-5 py-3 text-sm font-black text-white backdrop-blur transition hover:bg-white/15">Buy Leads</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="mb-6 flex flex-col gap-4 rounded-3xl border border-slate-200 bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-lg font-black text-slate-950">Business overview</h2>
                <p class="text-sm text-slate-500">Filter analytics by when leads entered your pipeline.</p>
            </div>

            <form method="GET" action="{{ route('dashboard') }}" class="flex items-center gap-3">
                <select name="filter" onchange="this.form.submit()" class="rounded-2xl border-slate-200 bg-slate-50 text-sm font-bold shadow-sm focus:border-cyan-500 focus:ring-cyan-500">
                    <option value="today" @selected($filter === 'today')>Today</option>
                    <option value="last_7_days" @selected($filter === 'last_7_days')>Last 7 Days</option>
                    <option value="this_month" @selected($filter === 'this_month')>This Month</option>
                    <option value="this_year" @selected($filter === 'this_year')>This Year</option>
                    <option value="all_time" @selected($filter === 'all_time')>All Time</option>
                </select>
            </form>
        </div>

        <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <div class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-bold text-slate-500">Total Leads</p>
                    <span class="rounded-2xl bg-blue-50 px-3 py-1 text-lg">🎯</span>
                </div>
                <p class="mt-4 text-4xl font-black tracking-tight text-slate-950">{{ number_format($totalLeads) }}</p>
                <p class="mt-2 text-xs font-semibold text-slate-500">{{ $unassignedLeads }} unassigned · {{ $newLeads }} new</p>
            </div>

            <div class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-bold text-slate-500">Qualified Leads</p>
                    <span class="rounded-2xl bg-amber-50 px-3 py-1 text-lg">🔥</span>
                </div>
                <p class="mt-4 text-4xl font-black tracking-tight text-amber-600">{{ number_format($qualifiedLeads) }}</p>
                <p class="mt-2 text-xs font-semibold text-slate-500">Ready for quotation follow-up</p>
            </div>

            <div class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-bold text-slate-500">Booked Trips</p>
                    <span class="rounded-2xl bg-emerald-50 px-3 py-1 text-lg">✅</span>
                </div>
                <p class="mt-4 text-4xl font-black tracking-tight text-emerald-600">{{ number_format($bookedTrips) }}</p>
                <p class="mt-2 text-xs font-semibold text-slate-500">{{ $conversionRate }}% lead-to-win conversion</p>
            </div>

            <div class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-bold text-slate-500">Open Pipeline</p>
                    <span class="rounded-2xl bg-cyan-50 px-3 py-1 text-lg">💰</span>
                </div>
                <p class="mt-4 text-4xl font-black tracking-tight text-slate-950">₹{{ number_format($pipelineValue) }}</p>
                <p class="mt-2 text-xs font-semibold text-slate-500">Avg lead budget ₹{{ number_format($averageBudget) }}</p>
            </div>
        </div>

        <div class="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
            <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm xl:col-span-2">
                <div class="mb-5 flex items-start justify-between gap-4">
                    <div>
                        <h3 class="text-lg font-black text-slate-950">Monthly lead trend</h3>
                        <p class="text-sm text-slate-500">Leads created month-by-month{{ $filter === 'all_time' ? '' : ' for ' . now()->year }}.</p>
                    </div>
                    <span class="rounded-full bg-slate-100 px-3 py-1 text-xs font-black text-slate-600">Live CRM</span>
                </div>
                <div class="h-80">
                    <canvas id="monthlyLeadsChart" data-labels='@json($months)' data-values='@json($leadCounts)'></canvas>
                </div>
            </section>

            <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                <div class="mb-5">
                    <h3 class="text-lg font-black text-slate-950">Lead sources</h3>
                    <p class="text-sm text-slate-500">Where demand is coming from.</p>
                </div>
                <div class="h-64">
                    <canvas id="sourceLeadsChart" data-labels='@json($sourceLabels)' data-values='@json($sourceData)'></canvas>
                </div>
            </section>
        </div>

        <div class="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
            <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                <div class="mb-5">
                    <h3 class="text-lg font-black text-slate-950">Lead status</h3>
                    <p class="text-sm text-slate-500">Pipeline health by stage.</p>
                </div>

                <div class="space-y-5">
                    @foreach ($statusDistribution as $status)
                        <div>
                            <div class="mb-2 flex justify-between gap-3">
                                <span class="text-sm font-bold text-slate-700">{{ $status['label'] }}</span>
                                <span class="text-sm font-semibold text-slate-500">{{ $status['count'] }} · {{ $status['percentage'] }}%</span>
                            </div>
                            <div class="h-3 overflow-hidden rounded-full bg-slate-100">
                                <div class="h-full rounded-full {{ $status['bar'] }}" style="width: {{ $status['percentage'] }}%"></div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </section>

            <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm xl:col-span-2">
                <div class="mb-5 flex items-center justify-between gap-4">
                    <div>
                        <h3 class="text-lg font-black text-slate-950">Recent leads</h3>
                        <p class="text-sm text-slate-500">Latest enquiries needing action.</p>
                    </div>
                    <a href="{{ route('leads.index') }}" class="text-sm font-black text-blue-600 hover:text-blue-700">View all</a>
                </div>

                <div class="overflow-hidden rounded-2xl border border-slate-100">
                    @forelse ($recentLeads as $lead)
                        <a href="{{ route('leads.show', $lead) }}" class="grid gap-4 border-b border-slate-100 bg-white p-4 transition last:border-b-0 hover:bg-slate-50 sm:grid-cols-[1.5fr_1fr_1fr_auto] sm:items-center">
                            <div>
                                <p class="font-black text-slate-950">{{ $lead->customer_name }}</p>
                                <p class="mt-1 text-sm font-semibold text-slate-500">{{ $lead->destination }} · {{ $lead->travellers }} traveller(s)</p>
                            </div>
                            <div class="text-sm font-semibold text-slate-600">{{ $lead->source }}</div>
                            <div class="text-sm font-semibold text-slate-600">{{ $lead->assignedUser?->name ?? 'Unassigned' }}</div>
                            <div class="text-left sm:text-right">
                                <span class="inline-flex rounded-full bg-blue-50 px-3 py-1 text-xs font-black text-blue-700">{{ $lead->status }}</span>
                                <p class="mt-1 text-xs font-semibold text-slate-400">{{ $lead->created_at->diffForHumans() }}</p>
                            </div>
                        </a>
                    @empty
                        <div class="p-6 text-sm font-semibold text-slate-500">No recent leads found. Add your first lead to activate the dashboard.</div>
                    @endforelse
                </div>
            </section>
        </div>

        <div class="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-2">
            <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                <div class="mb-5 flex items-center justify-between gap-4">
                    <div>
                        <h3 class="text-lg font-black text-slate-950">Upcoming trips</h3>
                        <p class="text-sm text-slate-500">Travel dates approaching soon.</p>
                    </div>
                </div>

                <div class="space-y-3">
                    @forelse ($upcomingTrips as $trip)
                        <div class="flex items-center justify-between rounded-2xl border border-slate-100 bg-slate-50 p-4">
                            <div>
                                <p class="font-black text-slate-950">{{ $trip->destination }}</p>
                                <p class="text-sm font-semibold text-slate-500">{{ $trip->customer_name }} · ₹{{ number_format($trip->budget ?? 0) }}</p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-black text-slate-800">{{ optional($trip->travel_date)->format('d M') }}</p>
                                <p class="text-xs font-semibold text-slate-500">{{ $trip->status }}</p>
                            </div>
                        </div>
                    @empty
                        <p class="rounded-2xl bg-slate-50 p-4 text-sm font-semibold text-slate-500">No upcoming trips yet.</p>
                    @endforelse
                </div>
            </section>

            <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                <div class="mb-5 flex items-center justify-between gap-4">
                    <div>
                        <h3 class="text-lg font-black text-slate-950">Fresh marketplace requests</h3>
                        <p class="text-sm text-slate-500">New B2C leads available to claim.</p>
                    </div>
                    <a href="{{ route('marketplace.travel-requests.index') }}" class="text-sm font-black text-blue-600 hover:text-blue-700">Buy leads</a>
                </div>

                <div class="space-y-3">
                    @forelse ($marketplaceRequests as $request)
                        <a href="{{ route('marketplace.travel-requests.show', $request) }}" class="block rounded-2xl border border-slate-100 bg-slate-50 p-4 transition hover:bg-cyan-50/70">
                            <div class="flex items-start justify-between gap-4">
                                <div>
                                    <p class="font-black text-slate-950">{{ $request->destination }}</p>
                                    <p class="text-sm font-semibold text-slate-500">{{ $request->travellers }} traveller(s) · {{ $request->travel_month ?? optional($request->travel_date)->format('M Y') ?? 'Flexible dates' }}</p>
                                </div>
                                <span class="rounded-full bg-emerald-100 px-3 py-1 text-xs font-black text-emerald-700">New</span>
                            </div>
                            <p class="mt-3 text-sm font-semibold text-slate-600">Budget: ₹{{ number_format($request->budget ?? 0) }} · {{ $request->hotel_category ?? 'Hotel flexible' }}</p>
                        </a>
                    @empty
                        <p class="rounded-2xl bg-slate-50 p-4 text-sm font-semibold text-slate-500">No open marketplace requests yet.</p>
                    @endforelse
                </div>
            </section>
        </div>
    </div>
</x-app-layout>
