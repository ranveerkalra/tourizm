<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Team Management
            </h2>

            <a href="{{ route('team-members.create') }}"
               class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700">
                + Add Team Member
            </a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">

                    <h3 class="text-lg font-semibold text-gray-800 mb-4">
                        Organization Team
                    </h3>

                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 text-sm">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-3 text-left font-semibold text-gray-600">Name</th>
                                    <th class="px-4 py-3 text-left font-semibold text-gray-600">Email</th>
                                    <th class="px-4 py-3 text-left font-semibold text-gray-600">Department</th>
                                    <th class="px-4 py-3 text-left font-semibold text-gray-600">Designation</th>
<th class="px-4 py-3 text-left font-semibold text-gray-600">Role</th>
                                    <th class="px-4 py-3 text-left font-semibold text-gray-600">Status</th>
                                    <th class="px-4 py-3 text-right font-semibold text-gray-600">Actions</th>
                                </tr>
                            </thead>

                            <tbody class="divide-y divide-gray-100 bg-white">
                                @forelse ($teamMembers as $member)
                                    <tr>
                                        <td class="px-4 py-3 font-medium text-gray-900">
                                            {{ $member->name }}
                                        </td>

                                        <td class="px-4 py-3 text-gray-600">
                                            {{ $member->email }}
                                        </td>

                                        <td class="px-4 py-3 text-gray-600">
                                            {{ $member->department ?? '—' }}
                                        </td>

                                        <td class="px-4 py-3 text-gray-600">
                                            {{ $member->designation ?? '—' }}
                                        </td>

                                        <td class="px-4 py-3">
                                            <span class="px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-700">
                                                {{ ucfirst($member->role) }}
                                            </span>
                                        </td>

                                        <td class="px-4 py-3">
                                            <span class="px-2 py-1 rounded-full text-xs
                                                {{ $member->status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' }}">
                                                {{ $member->status }}
                                            </span>
                                        </td>

                                        <td class="px-4 py-3 text-right">
                                            <a href="{{ route('team-members.edit', $member) }}"
   class="text-blue-600 hover:text-blue-800 font-medium">
    Edit
</a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="px-4 py-10 text-center text-gray-500">
                                            No team members found.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4">
                        {{ $teamMembers->links() }}
                    </div>

                </div>
            </div>

        </div>
    </div>
</x-app-layout>
