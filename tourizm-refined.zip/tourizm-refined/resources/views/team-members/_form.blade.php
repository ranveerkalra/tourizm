@csrf

<h3 class="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">
    Personal Information
</h3>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6">

    <div>
        <label class="block text-sm font-medium text-gray-700">Name</label>
        <input type="text" name="name" value="{{ old('name', $teamMember->name) }}"
               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('name') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Email</label>
        <input type="email" name="email" value="{{ old('email', $teamMember->email) }}"
               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('email') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Phone</label>
        <input type="text" name="phone" value="{{ old('phone', $teamMember->phone) }}"
               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('phone') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
    </div>

    <div>
    <label class="block text-sm font-medium text-gray-700">
        Employee Code
    </label>

    <input type="text"
           value="{{ $teamMember->employee_code ?? 'Will be generated automatically' }}"
           readonly
           class="mt-1 block w-full rounded-md border-gray-300 bg-gray-100 text-gray-500 shadow-sm">
</div>

<!-- Organization Information -->
<h3 class="md:col-span-2 text-lg font-semibold text-gray-800 border-b pb-2 mt-8 mb-4">
    Organization Information
</h3>

    <div>
        <label class="block text-sm font-medium text-gray-700">System Role</label>
        <select name="role" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
            @foreach (['admin', 'manager', 'executive'] as $role)
                <option value="{{ $role }}" @selected(old('role', $teamMember->role ?? 'executive') === $role)>
                    {{ ucfirst($role) }}
                </option>
            @endforeach
        </select>
        @error('role') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Department</label>
        <select name="department" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
            <option value="">Select Department</option>
            @foreach (['Sales', 'Accounts', 'Procurement', 'Operations', 'Support', 'Management'] as $department)
                <option value="{{ $department }}" @selected(old('department', $teamMember->department) === $department)>
                    {{ $department }}
                </option>
            @endforeach
        </select>
        @error('department') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Designation</label>
        <input type="text" name="designation" value="{{ old('designation', $teamMember->designation) }}"
               placeholder="Sales Executive, Accounts Manager..."
               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
        @error('designation') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Status</label>
        <select name="status" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
            @foreach (['Active', 'Inactive', 'Suspended'] as $status)
                <option value="{{ $status }}" @selected(old('status', $teamMember->status ?? 'Active') === $status)>
                    {{ $status }}
                </option>
            @endforeach
        </select>
        @error('status') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
    </div>

   <!-- Login Credentials -->
<div class="md:col-span-2 mt-8">

    <h3 class="text-lg font-semibold text-gray-800 border-b pb-2">
        Login Credentials
    </h3>

    @if($teamMember->exists)
        <div class="mt-3 mb-5 rounded-md border border-blue-200 bg-blue-50 p-3">
            <p class="text-sm text-blue-700">
                <strong>Note:</strong> Leave these fields blank if you don't want to change the password.
            </p>
        </div>
    @endif

</div>

<div>
    <label class="block text-sm font-medium text-gray-700">
        {{ $teamMember->exists ? 'New Password' : 'Password' }}
    </label>

    <input type="password"
           name="password"
           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">

    @error('password')
        <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
    @enderror
</div>

<div>
    <label class="block text-sm font-medium text-gray-700">
        {{ $teamMember->exists ? 'Confirm New Password' : 'Confirm Password' }}
    </label>

    <input type="password"
           name="password_confirmation"
           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">


<div class="md:col-span-2 mt-10 flex justify-center gap-4">
    <a href="{{ route('team-members.index') }}"
       class="inline-flex items-center px-6 py-3 bg-gray-500 text-white rounded-lg font-semibold shadow hover:bg-gray-600 transition">
        Cancel
    </a>

    <button type="submit"
            class="inline-flex items-center px-6 py-3 bg-yellow-500 text-white rounded-lg font-semibold shadow hover:bg-yellow-600 transition">
        {{ $teamMember->exists ? 'Update Team Member' : 'Save Team Member' }}
    </button>
</div>

</div>
