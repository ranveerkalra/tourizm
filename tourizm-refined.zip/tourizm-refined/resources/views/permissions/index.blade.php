<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Permission Management
            </h2>
            <p class="mt-1 text-sm text-gray-500">
                Manage default powers for Admin, Manager, and Executive roles.
            </p>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 rounded-md bg-green-50 p-4 text-sm text-green-700">
                    {{ session('success') }}
                </div>
            @endif

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

                @foreach ($roles as $roleKey => $roleLabel)
                    <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                        <div class="p-5 border-b">
                            <h3 class="text-lg font-semibold text-gray-900">
                                {{ $roleLabel }}
                            </h3>
                            <p class="text-sm text-gray-500">
                                Default permissions for {{ $roleLabel }} users.
                            </p>
                        </div>

                        <form method="POST" action="{{ route('permissions.roles.update', $roleKey) }}">
                            @csrf
                            @method('PUT')

                            <div class="p-5 space-y-6">
                                @foreach ($permissions as $module => $modulePermissions)
                                    <div>
                                        <h4 class="text-sm font-bold text-gray-700 uppercase tracking-wide mb-3">
                                            {{ $module }}
                                        </h4>

                                        <div class="space-y-2">
                                            @foreach ($modulePermissions as $permission)
                                                <label class="flex items-center gap-2 text-sm text-gray-700">
                                                    <input type="checkbox"
                                                           name="permissions[]"
                                                           value="{{ $permission->id }}"
                                                           class="rounded border-gray-300 text-blue-600 shadow-sm focus:ring-blue-500"
                                                           @checked(in_array($permission->id, $rolePermissions[$roleKey] ?? []))>

                                                    <span>{{ $permission->display_name }}</span>
                                                </label>
                                            @endforeach
                                        </div>
                                    </div>
                                @endforeach
                            </div>

                            <div class="p-5 border-t bg-gray-50 flex justify-end">
                                <button type="submit"
                                        class="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-semibold hover:bg-blue-700">
                                    Save {{ $roleLabel }}
                                </button>
                            </div>
                        </form>
                    </div>
                @endforeach

            </div>

        </div>
    </div>
</x-app-layout>
