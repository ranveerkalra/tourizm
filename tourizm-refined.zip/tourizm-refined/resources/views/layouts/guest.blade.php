<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Tourizm AI') }}</title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600,700,800,900&display=swap" rel="stylesheet" />

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="font-sans text-slate-900 antialiased">
    <div class="relative isolate flex min-h-screen items-center justify-center overflow-hidden bg-slate-950 px-4 py-10">
        <div class="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.25),transparent_30%),radial-gradient(circle_at_bottom_right,rgba(59,130,246,0.26),transparent_28%)]"></div>

        <div class="w-full max-w-md">
            <a href="{{ url('/') }}" class="mx-auto mb-8 flex w-fit items-center gap-3 text-white">
                <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 via-cyan-400 to-emerald-400 text-lg font-black text-slate-950 shadow-lg shadow-cyan-500/20">T</div>
                <div>
                    <p class="text-xl font-black tracking-tight">Tourizm AI</p>
                    <p class="text-[11px] font-black uppercase tracking-[0.28em] text-cyan-200/70">Travel CRM</p>
                </div>
            </a>

            <div class="rounded-[2rem] border border-white/10 bg-white p-6 shadow-2xl sm:p-8">
                {{ $slot }}
            </div>
        </div>
    </div>
</body>
</html>
