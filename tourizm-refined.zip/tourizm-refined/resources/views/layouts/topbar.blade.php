@php
    $user = auth()->user();
@endphp

<div class="sticky top-0 z-30 border-b border-slate-200 bg-white/85 px-5 py-3 backdrop-blur-xl sm:px-8">
    <div class="flex items-center justify-between gap-4">
        <div class="flex min-w-0 items-center gap-3">
            <button type="button" class="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-700 shadow-sm transition hover:bg-slate-50 md:hidden" @click="sidebarOpen = true" aria-label="Open sidebar">
                <span class="text-xl leading-none">☰</span>
            </button>

            <div class="min-w-0">
                <p class="truncate text-sm font-semibold text-slate-950">{{ $user?->organization?->name ?? 'Tourizm Workspace' }}</p>
                <p class="truncate text-xs text-slate-500">AI-assisted travel CRM · {{ now()->format('d M Y') }}</p>
            </div>
        </div>

        <div class="flex items-center gap-3">
            <a href="{{ route('leads.create') }}" class="hidden rounded-2xl bg-slate-950 px-4 py-2 text-sm font-bold text-white shadow-sm transition hover:bg-slate-800 sm:inline-flex">
                + New Lead
            </a>

            <button type="button" class="relative inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:bg-slate-50" aria-label="Notifications">
                <span>🔔</span>
                <span class="absolute -right-1 -top-1 h-5 min-w-5 rounded-full bg-rose-500 px-1 text-center text-[11px] font-bold leading-5 text-white">3</span>
            </button>

            <div class="hidden items-center gap-3 rounded-2xl border border-slate-200 bg-white px-3 py-2 shadow-sm sm:flex">
                <div class="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 text-sm font-black text-white">
                    {{ strtoupper(substr($user?->name ?? 'A', 0, 1)) }}
                </div>
                <div class="min-w-0">
                    <p class="truncate text-sm font-bold text-slate-900">{{ $user?->name ?? 'Agency Admin' }}</p>
                    <p class="truncate text-xs text-slate-500">{{ ucfirst($user?->role ?? 'user') }}</p>
                </div>
            </div>

            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 shadow-sm transition hover:bg-slate-50">
                    Logout
                </button>
            </form>
        </div>
    </div>
</div>
