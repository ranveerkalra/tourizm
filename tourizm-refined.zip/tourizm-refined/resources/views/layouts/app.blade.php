<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Tourizm AI') }}</title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600,700,800&display=swap" rel="stylesheet" />

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="font-sans antialiased bg-slate-950 text-slate-900">
    <div x-data="{ sidebarOpen: false }" class="min-h-screen bg-slate-100">
        <div x-cloak x-show="sidebarOpen" x-transition.opacity class="fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-sm md:hidden" @click="sidebarOpen = false"></div>

        <div x-cloak x-show="sidebarOpen" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="-translate-x-full" x-transition:enter-end="translate-x-0" x-transition:leave="transition ease-in duration-150" x-transition:leave-start="translate-x-0" x-transition:leave-end="-translate-x-full" class="fixed inset-y-0 left-0 z-50 md:hidden">
            @include('layouts.sidebar', ['mobile' => true])
        </div>

        <div class="min-h-screen md:flex">
            @include('layouts.sidebar', ['mobile' => false])

            <div class="flex min-w-0 flex-1 flex-col">
                @include('layouts.topbar')

                @isset($header)
                    <header class="border-b border-slate-200 bg-white/80 backdrop-blur-xl">
                        <div class="px-5 py-5 sm:px-8">
                            {{ $header }}
                        </div>
                    </header>
                @endisset

                @if (session('success') || session('error'))
                    <div class="px-5 pt-5 sm:px-8">
                        @if (session('success'))
                            <div class="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800 shadow-sm">
                                {{ session('success') }}
                            </div>
                        @endif

                        @if (session('error'))
                            <div class="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-medium text-rose-800 shadow-sm">
                                {{ session('error') }}
                            </div>
                        @endif
                    </div>
                @endif

                <main class="flex-1">
                    {{ $slot }}
                </main>
            </div>
        </div>
    </div>
</body>
</html>
