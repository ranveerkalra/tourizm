@php
    $mobile = $mobile ?? false;
    $user = auth()->user();
    $homeRoute = $user?->homeRoute() ?? 'leads.index';

    $groups = [
        'Main' => [
            ['label' => 'Dashboard', 'icon' => '📊', 'route' => 'dashboard', 'active' => 'dashboard', 'show' => $user?->isAdmin()],
            ['label' => 'Buy Leads', 'icon' => '🧲', 'route' => 'marketplace.travel-requests.index', 'active' => 'marketplace.travel-requests.*', 'show' => $user?->isAdmin() || $user?->isManager() || $user?->hasPermission('view_marketplace')],
            ['label' => 'Leads', 'icon' => '🎯', 'route' => 'leads.index', 'active' => 'leads.*', 'show' => $user?->isAdmin() || $user?->hasPermission('view_leads')],
            ['label' => 'Customers', 'icon' => '🧑‍💼', 'route' => 'customers.index', 'active' => 'customers.*', 'show' => $user?->isAdmin() || $user?->hasPermission('view_customers')],
            ['label' => 'Quotations', 'icon' => '🧾', 'route' => 'quotations.index', 'active' => 'quotations.*', 'show' => $user?->isAdmin() || $user?->hasPermission('view_quotations')],
        ],
        'Workspace' => [
            ['label' => 'Team', 'icon' => '👥', 'route' => 'team-members.index', 'active' => 'team-members.*', 'show' => $user?->isAdmin() || $user?->hasPermission('view_team')],
            ['label' => 'Permissions', 'icon' => '🔐', 'route' => 'permissions.index', 'active' => 'permissions.*', 'show' => $user?->isAdmin()],
        ],
        'Coming Soon' => [
            ['label' => 'Bookings', 'icon' => '🧳', 'route' => null, 'active' => null, 'show' => true],
            ['label' => 'Reports', 'icon' => '📈', 'route' => null, 'active' => null, 'show' => true],
            ['label' => 'AI Replies', 'icon' => '✨', 'route' => null, 'active' => null, 'show' => true],
        ],
    ];
@endphp

<aside class="{{ $mobile ? 'flex h-full w-72 flex-col' : 'hidden md:flex md:w-72 md:flex-col' }} border-r border-white/10 bg-slate-950 text-white shadow-2xl">
    <div class="flex h-16 items-center justify-between border-b border-white/10 px-5">
        <a href="{{ route($homeRoute) }}" class="flex items-center gap-3">
            <div class="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 via-cyan-400 to-emerald-400 font-black text-slate-950 shadow-lg shadow-cyan-500/20">
                T
            </div>
            <div>
                <p class="text-lg font-black tracking-tight">Tourizm AI</p>
                <p class="text-[11px] font-semibold uppercase tracking-[0.25em] text-cyan-200/70">Travel CRM</p>
            </div>
        </a>

        @if($mobile)
            <button type="button" class="rounded-xl p-2 text-slate-300 hover:bg-white/10" @click="sidebarOpen = false" aria-label="Close sidebar">✕</button>
        @endif
    </div>

    <nav class="flex-1 overflow-y-auto px-4 py-5">
        @foreach ($groups as $group => $items)
            @php $visibleItems = collect($items)->filter(fn ($item) => $item['show']); @endphp

            @if ($visibleItems->isNotEmpty())
                <div class="mb-6">
                    <h3 class="mb-2 px-3 text-[11px] font-black uppercase tracking-[0.2em] text-slate-500">{{ $group }}</h3>

                    <div class="space-y-1">
                        @foreach ($visibleItems as $item)
                            @php $isActive = $item['active'] && request()->routeIs($item['active']); @endphp

                            @if ($item['route'])
                                <a href="{{ route($item['route']) }}" class="group flex items-center gap-3 rounded-2xl px-3 py-3 text-sm font-bold transition {{ $isActive ? 'bg-white text-slate-950 shadow-lg shadow-cyan-950/20' : 'text-slate-300 hover:bg-white/10 hover:text-white' }}">
                                    <span class="flex h-9 w-9 items-center justify-center rounded-xl {{ $isActive ? 'bg-cyan-100' : 'bg-white/10 group-hover:bg-white/15' }}">{{ $item['icon'] }}</span>
                                    <span>{{ $item['label'] }}</span>
                                </a>
                            @else
                                <div class="flex items-center gap-3 rounded-2xl px-3 py-3 text-sm font-bold text-slate-500">
                                    <span class="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5">{{ $item['icon'] }}</span>
                                    <span>{{ $item['label'] }}</span>
                                    <span class="ml-auto rounded-full bg-white/5 px-2 py-0.5 text-[10px] uppercase tracking-wider text-slate-500">Soon</span>
                                </div>
                            @endif
                        @endforeach
                    </div>
                </div>
            @endif
        @endforeach
    </nav>

    <div class="border-t border-white/10 p-4">
        <div class="rounded-3xl border border-white/10 bg-white/5 p-4">
            <div class="flex items-center gap-3">
                <div class="flex h-11 w-11 items-center justify-center rounded-2xl bg-white text-sm font-black text-slate-950">
                    {{ strtoupper(substr($user?->name ?? 'A', 0, 1)) }}
                </div>
                <div class="min-w-0">
                    <p class="truncate text-sm font-black text-white">{{ $user?->organization?->name ?? 'Agency Workspace' }}</p>
                    <p class="truncate text-xs text-slate-400">{{ ucfirst($user?->role ?? 'User') }} account</p>
                </div>
            </div>
            <div class="mt-4 rounded-2xl bg-cyan-400/10 p-3 text-xs font-semibold leading-5 text-cyan-100">
                AI quote drafting, lead scoring, reminders and vendor booking modules are ready to plug in next.
            </div>
        </div>
    </div>
</aside>
