<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                Edit Quotation
            </h2>

            <a
                href="{{ route('quotations.show', $quotation) }}"
                class="rounded-md bg-gray-800 px-4 py-2 text-sm font-medium text-white hover:bg-gray-700"
            >
                Back to Details
            </a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-5xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white p-6 shadow-sm sm:rounded-lg">
                @include('quotations._form', [
                    'action' => route('quotations.update', $quotation),
                    'method' => 'PUT',
                    'buttonText' => 'Update Quotation',
                ])
            </div>
        </div>
    </div>
</x-app-layout>
