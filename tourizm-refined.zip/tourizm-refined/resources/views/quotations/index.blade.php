<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                Quotation Management
            </h2>

            <a
                href="{{ route('quotations.create') }}"
                class="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
            >
                + New Quotation
            </a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            @if (session('success'))
                <div class="mb-4 rounded-md bg-green-50 p-4 text-sm text-green-700">
                    {{ session('success') }}
                </div>
            @endif

            <div class="mb-6 rounded-lg bg-white p-4 shadow-sm">
                <form method="GET" action="{{ route('quotations.index') }}" class="grid grid-cols-1 gap-4 md:grid-cols-4">
                    <div class="md:col-span-2">
                        <input
                            type="text"
                            name="search"
                            value="{{ request('search') }}"
                            placeholder="Search by quotation number, title, customer or destination..."
                            class="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        >
                    </div>

                    <div>
                        <select
                            name="status"
                            class="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        >
                            <option value="">All Status</option>
                            @foreach (\App\Models\Quotation::statuses() as $status)
                                <option value="{{ $status }}" @selected(request('status') === $status)>
                                    {{ $status }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="flex gap-2">
                        <button
                            type="submit"
                            class="rounded-md bg-gray-800 px-4 py-2 text-sm font-medium text-white hover:bg-gray-700"
                        >
                            🔍 Search
                        </button>

                        <a
                            href="{{ route('quotations.index') }}"
                            class="rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                        >
                            Clear
                        </a>
                    </div>
                </form>
            </div>

            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                @if ($quotations->count())
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                                        Quotation
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                                        Customer
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                                        Destination
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                                        Amount
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                                        Status
                                    </th>
                                    <th class="px-6 py-3 text-right text-xs font-medium uppercase tracking-wider text-gray-500">
                                        Actions
                                    </th>
                                </tr>
                            </thead>

                            <tbody class="divide-y divide-gray-200 bg-white">
                                @foreach ($quotations as $quotation)
                                    @php
                                        $statusClass = match ($quotation->status) {
                                            'Draft' => 'bg-gray-100 text-gray-700',
                                            'Sent' => 'bg-blue-100 text-blue-700',
                                            'Accepted' => 'bg-green-100 text-green-700',
                                            'Rejected' => 'bg-red-100 text-red-700',
                                            default => 'bg-gray-100 text-gray-700',
                                        };
                                    @endphp

                                    <tr class="hover:bg-gray-50">
                                        <td class="px-6 py-4">
                                            <div class="font-medium text-gray-900">
                                                {{ $quotation->quotation_number }}
                                            </div>
                                            <div class="text-sm text-gray-500">
                                                {{ $quotation->title }}
                                            </div>
                                        </td>

                                        <td class="px-6 py-4 text-sm text-gray-700">
                                            {{ $quotation->customer?->full_name ?? '—' }}
                                        </td>

                                        <td class="px-6 py-4 text-sm text-gray-700">
                                            {{ $quotation->destination ?? '—' }}
                                        </td>

                                        <td class="px-6 py-4 text-sm font-medium text-gray-900">
                                            {{ $quotation->currency }} {{ number_format((float) $quotation->total_amount, 2) }}
                                        </td>

                                        <td class="px-6 py-4">
                                            <span class="inline-flex rounded-full px-2 py-1 text-xs font-semibold {{ $statusClass }}">
                                                {{ $quotation->status }}
                                            </span>
                                        </td>

                                        <td class="px-6 py-4 text-right text-sm font-medium">
                                            <div class="flex justify-end gap-3">
                                                <a
                                                    href="{{ route('quotations.show', $quotation) }}"
                                                    class="text-indigo-600 hover:text-indigo-900"
                                                >
                                                    View
                                                </a>

                                                <a
                                                    href="{{ route('quotations.edit', $quotation) }}"
                                                    class="text-blue-600 hover:text-blue-900"
                                                >
                                                    Edit
                                                </a>

                                                <form
                                                    method="POST"
                                                    action="{{ route('quotations.destroy', $quotation) }}"
                                                    onsubmit="return confirm('Are you sure you want to delete this quotation?');"
                                                >
                                                    @csrf
                                                    @method('DELETE')

                                                    <button
                                                        type="submit"
                                                        class="text-red-600 hover:text-red-900"
                                                    >
                                                        Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div class="border-t border-gray-200 px-6 py-4">
                        {{ $quotations->links() }}
                    </div>
                @else
                    <div class="p-10 text-center">
                        <div class="text-4xl">📄</div>
                        <h3 class="mt-3 text-lg font-medium text-gray-900">No Quotations Yet</h3>
                        <p class="mt-1 text-sm text-gray-500">
                            Create your first customer quotation.
                        </p>

                        <a
                            href="{{ route('quotations.create') }}"
                            class="mt-5 inline-flex rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
                        >
                            Add First Quotation
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </div>
</x-app-layout>
