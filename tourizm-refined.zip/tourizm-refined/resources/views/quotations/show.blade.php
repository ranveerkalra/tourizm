<x-app-layout>
    @php
        $customerName = $quotation->customer?->full_name
            ?? $quotation->lead?->customer_name
            ?? '—';

        $customerPhone = $quotation->customer?->phone
            ?? $quotation->lead?->phone
            ?? '—';

        $customerEmail = $quotation->customer?->email
            ?? $quotation->lead?->email
            ?? null;

        $leadSource = $quotation->lead?->source ?? 'Manual';

        $totalTravellers = ($quotation->adults !== null || $quotation->children !== null)
            ? ((int) ($quotation->adults ?? 0) + (int) ($quotation->children ?? 0))
            : ($quotation->travellers ?? '—');

        $offerTotal = $quotation->currency . ' ' . number_format((float) $quotation->total_amount, 2);
    @endphp

    <x-slot name="header">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">
                    Quotation Details
                </h2>

                <p class="mt-1 text-sm text-gray-500">
                    {{ $quotation->quotation_number }}
                </p>
            </div>

            <div class="flex items-center gap-2">
                <a
                    href="{{ route('quotations.edit', $quotation) }}"
                    class="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"
                >
                    Edit
                </a>

                <a
                    href="{{ route('quotations.index') }}"
                    class="rounded-lg bg-gray-800 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-700"
                >
                    Back
                </a>
            </div>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-6 rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
                    {{ session('success') }}
                </div>
            @endif

            @if (session('error'))
                <div class="mb-6 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                    {{ session('error') }}
                </div>
            @endif

            {{-- Status Actions --}}
            <div class="mb-6 rounded-xl bg-white p-6 shadow-sm">
                <div class="flex flex-wrap items-center justify-between gap-4">
                    <div>
                        <p class="text-sm text-gray-500">Quotation Status</p>

                        <span class="mt-1 inline-flex rounded-full px-3 py-1 text-sm font-semibold {{ $quotation->statusBadgeClass() }}">
                            {{ $quotation->statusLabel() }}
                        </span>
                    </div>

                    <div class="flex flex-wrap gap-2">
                        @if ($quotation->canBeSent())
                            <form method="POST" action="{{ route('quotations.send', $quotation) }}">
                                @csrf
                                @method('PATCH')

                                <button
                                    type="submit"
                                    class="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"
                                >
                                    Mark as Sent
                                </button>
                            </form>
                        @endif

                        @if ($quotation->canBeAccepted())
                            <form method="POST" action="{{ route('quotations.accept', $quotation) }}">
                                @csrf
                                @method('PATCH')

                                <button
                                    type="submit"
                                    class="rounded-lg bg-green-600 px-4 py-2 text-sm font-semibold text-white hover:bg-green-700"
                                >
                                    Accept
                                </button>
                            </form>
                        @endif

                        @if ($quotation->canBeRejected())
                            <form method="POST" action="{{ route('quotations.reject', $quotation) }}">
                                @csrf
                                @method('PATCH')

                                <button
                                    type="submit"
                                    onclick="return confirm('Are you sure you want to reject this quotation?')"
                                    class="rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700"
                                >
                                    Reject
                                </button>
                            </form>
                        @endif

                        @if ($quotation->canBeExpired())
                            <form method="POST" action="{{ route('quotations.expire', $quotation) }}">
                                @csrf
                                @method('PATCH')

                                <button
                                    type="submit"
                                    onclick="return confirm('Are you sure you want to expire this quotation?')"
                                    class="rounded-lg bg-yellow-500 px-4 py-2 text-sm font-semibold text-white hover:bg-yellow-600"
                                >
                                    Expire
                                </button>
                            </form>
                        @endif
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

                {{-- Main Offer --}}
                <div class="space-y-6 lg:col-span-2">

                    {{-- Offer Header --}}
                    <div class="rounded-xl bg-white p-6 shadow-sm">
                        <div class="flex flex-wrap items-start justify-between gap-4">
                            <div>
                                <p class="text-sm font-semibold uppercase tracking-wide text-blue-600">
                                    First Travel Offer
                                </p>

                                <h3 class="mt-2 text-2xl font-bold text-gray-900">
                                    {{ $quotation->title }}
                                </h3>

                                <p class="mt-2 text-sm text-gray-500">
                                    Created by {{ $quotation->creator?->name ?? '—' }}
                                    @if ($quotation->valid_until)
                                        · Valid until {{ $quotation->valid_until->format('d M Y') }}
                                    @endif
                                </p>
                            </div>

                            <div class="text-right">
                                <p class="text-sm text-gray-500">Total Offer</p>
                                <p class="text-2xl font-bold text-gray-900">
                                    {{ $offerTotal }}
                                </p>
                            </div>
                        </div>
                    </div>

                    {{-- Lead / Travel Summary --}}
                    <div class="rounded-xl bg-white p-6 shadow-sm">
                        <h3 class="text-lg font-semibold text-gray-900">
                            Enquiry Summary
                        </h3>

                        <div class="mt-6 grid grid-cols-1 gap-6 md:grid-cols-5">
                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Customer</p>
                                <p class="mt-2 font-semibold text-gray-900">{{ $customerName }}</p>
                                <p class="text-sm text-gray-500">{{ $customerPhone }}</p>
                                @if ($customerEmail)
                                    <p class="text-xs text-gray-400">{{ $customerEmail }}</p>
                                @endif
                            </div>

                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Destination</p>
                                <p class="mt-2 font-semibold text-gray-900">{{ $quotation->destination ?? '—' }}</p>
                                <p class="text-sm text-gray-500">{{ $leadSource }}</p>
                            </div>

                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Travel Plan</p>
                                <p class="mt-2 font-semibold text-gray-900">
                                    {{ $quotation->travel_start_date?->format('d M Y') ?? 'No date' }}
                                </p>
                                <p class="text-sm text-gray-500">
                                    {{ $quotation->duration_days ? $quotation->duration_days . ' day(s)' : 'Duration not set' }}
                                </p>
                            </div>

                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Pax / Hotel</p>
                                <p class="mt-2 font-semibold text-gray-900">
                                    {{ $totalTravellers }} traveller(s)
                                </p>
                                <p class="text-sm text-gray-500">
                                    {{ $quotation->adults ?? 0 }} adult(s), {{ $quotation->children ?? 0 }} child(ren)
                                </p>
                                <p class="text-xs text-gray-400">
                                    {{ $quotation->hotel_category ?? 'Hotel not set' }}
                                </p>
                            </div>

                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Budget</p>
                                <p class="mt-2 font-semibold text-gray-900">
                                    {{ $quotation->currency }} {{ number_format((float) $quotation->subtotal, 2) }}
                                </p>
                                <p class="text-sm text-gray-500">Offer price</p>
                            </div>
                        </div>
                    </div>

                    {{-- Deal Details --}}
                    <div class="rounded-xl bg-white p-6 shadow-sm">
                        <h3 class="text-lg font-semibold text-gray-900">
                            Best Available Deal
                        </h3>

                        <div class="mt-6">
                            <h4 class="text-sm font-semibold text-gray-700">
                                Itinerary Summary
                            </h4>
                            <div class="mt-2 rounded-lg border border-gray-200 bg-gray-50 p-4 text-sm leading-6 text-gray-700 whitespace-pre-line">
                                {{ $quotation->itinerary_summary ?: 'No itinerary summary added.' }}
                            </div>
                        </div>

                        <div class="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
                            <div>
                                <h4 class="text-sm font-semibold text-gray-700">
                                    Inclusions
                                </h4>
                                <div class="mt-2 rounded-lg border border-green-100 bg-green-50 p-4 text-sm leading-6 text-gray-700 whitespace-pre-line">
                                    {{ $quotation->inclusions ?: 'No inclusions added.' }}
                                </div>
                            </div>

                            <div>
                                <h4 class="text-sm font-semibold text-gray-700">
                                    Exclusions
                                </h4>
                                <div class="mt-2 rounded-lg border border-red-100 bg-red-50 p-4 text-sm leading-6 text-gray-700 whitespace-pre-line">
                                    {{ $quotation->exclusions ?: 'No exclusions added.' }}
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Terms & Notes --}}
                    <div class="rounded-xl bg-white p-6 shadow-sm">
                        <h3 class="text-lg font-semibold text-gray-900">
                            Terms & Notes
                        </h3>

                        <div class="mt-6">
                            <h4 class="text-sm font-semibold text-gray-700">
                                Terms & Conditions
                            </h4>
                            <div class="mt-2 rounded-lg border border-gray-200 bg-gray-50 p-4 text-sm leading-6 text-gray-700 whitespace-pre-line">
                                {{ $quotation->terms ?: 'No terms added.' }}
                            </div>
                        </div>

                        <div class="mt-6">
                            <h4 class="text-sm font-semibold text-gray-700">
                                Notes
                            </h4>
                            <div class="mt-2 rounded-lg border border-gray-200 bg-gray-50 p-4 text-sm leading-6 text-gray-700 whitespace-pre-line">
                                {{ $quotation->notes ?: 'No notes added.' }}
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Sidebar --}}
                <div class="space-y-6">

                    {{-- Price Summary --}}
                    <div class="rounded-xl bg-white p-6 shadow-sm">
                        <div class="flex items-center justify-between">
                            <h3 class="text-lg font-semibold text-gray-900">
                                Price Summary
                            </h3>

                            <span class="inline-flex rounded-full px-2 py-1 text-xs font-semibold {{ $quotation->statusBadgeClass() }}">
                                {{ $quotation->statusLabel() }}
                            </span>
                        </div>

                        <div class="mt-6 space-y-4">
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-500">Subtotal</span>
                                <span class="font-medium text-gray-900">
                                    {{ $quotation->currency }} {{ number_format((float) $quotation->subtotal, 2) }}
                                </span>
                            </div>

                            <div class="flex justify-between text-sm">
                                <span class="text-gray-500">Discount</span>
                                <span class="font-medium text-gray-900">
                                    {{ $quotation->currency }} {{ number_format((float) $quotation->discount, 2) }}
                                </span>
                            </div>

                            <div class="flex justify-between text-sm">
                                <span class="text-gray-500">Tax</span>
                                <span class="font-medium text-gray-900">
                                    {{ $quotation->currency }} {{ number_format((float) $quotation->tax, 2) }}
                                </span>
                            </div>

                            <div class="border-t border-gray-200 pt-4">
                                <div class="flex justify-between">
                                    <span class="text-base font-semibold text-gray-900">Total</span>
                                    <span class="text-base font-bold text-gray-900">
                                        {{ $quotation->currency }} {{ number_format((float) $quotation->total_amount, 2) }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Linked Records --}}
                    <div class="rounded-xl bg-white p-6 shadow-sm">
                        <h3 class="text-lg font-semibold text-gray-900">
                            Linked Records
                        </h3>

                        <div class="mt-4 space-y-4 text-sm">
                            <div>
                                <p class="text-gray-500">Linked Lead</p>
                                <p class="font-medium text-gray-900">
                                    {{ $quotation->lead?->customer_name ?? '—' }}
                                </p>
                            </div>

                            <div>
                                <p class="text-gray-500">Customer</p>
                                <p class="font-medium text-gray-900">
                                    {{ $quotation->customer?->full_name ?? '—' }}
                                </p>
                            </div>

                            <div>
                                <p class="text-gray-500">Travel End Date</p>
                                <p class="font-medium text-gray-900">
                                    {{ $quotation->travel_end_date?->format('d M Y') ?? '—' }}
                                </p>
                            </div>
                        </div>
                    </div>

                    {{-- Future Messaging Placeholder --}}
                    <div class="rounded-xl border border-dashed border-gray-300 bg-white p-6">
                        <h3 class="text-lg font-semibold text-gray-900">
                            Quick Reply
                        </h3>

                        <p class="mt-2 text-sm text-gray-500">
                            Messaging and negotiation history will be added here later.
                        </p>

                        <div class="mt-4 space-y-2">
                            <button type="button" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-left text-sm text-gray-700">
                                Customer asked for hotel upgrade
                            </button>

                            <button type="button" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-left text-sm text-gray-700">
                                Customer requested lower price
                            </button>

                            <button type="button" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-left text-sm text-gray-700">
                                Customer accepted the offer
                            </button>
                        </div>
                    </div>

                    {{-- Delete --}}
                    <form
                        method="POST"
                        action="{{ route('quotations.destroy', $quotation) }}"
                        onsubmit="return confirm('Are you sure you want to delete this quotation?');"
                    >
                        @csrf
                        @method('DELETE')

                        <button
                            type="submit"
                            class="w-full rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700"
                        >
                            Delete Quotation
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
