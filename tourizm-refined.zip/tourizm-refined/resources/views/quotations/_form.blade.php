@php
    $quotation = $quotation ?? new \App\Models\Quotation();
    $selectedLead = $selectedLead ?? null;

    $isEdit = $quotation->exists ?? false;
    $activeLead = $selectedLead ?? $quotation->lead ?? null;
    $hasLeadContext = $activeLead !== null;

    $formatDateForInput = function ($value) {
        if (! $value) {
            return '';
        }

        if ($value instanceof \Carbon\CarbonInterface) {
            return $value->format('Y-m-d');
        }

        return \Carbon\Carbon::parse($value)->format('Y-m-d');
    };

    $formatDateForDisplay = function ($value) {
        if (! $value) {
            return 'No date';
        }

        if ($value instanceof \Carbon\CarbonInterface) {
            return $value->format('d M Y');
        }

        return \Carbon\Carbon::parse($value)->format('d M Y');
    };

    $leadTravelDate = $activeLead?->travel_date;

    $travelStartValue = old(
        'travel_start_date',
        $formatDateForInput($quotation->travel_start_date ?? null)
            ?: $formatDateForInput($leadTravelDate)
    );

    $durationValue = old(
        'duration_days',
        $quotation->duration_days ?? $activeLead?->duration_days ?? null
    );

    $adultsValue = old(
        'adults',
        $quotation->adults ?? $activeLead?->adults ?? null
    );

    $childrenValue = old(
        'children',
        $quotation->children ?? $activeLead?->children ?? null
    );

    $travellersValue = old(
        'travellers',
        $quotation->travellers
            ?? (($adultsValue !== null || $childrenValue !== null)
                ? ((int) ($adultsValue ?? 0) + (int) ($childrenValue ?? 0))
                : ($activeLead?->travellers ?? 1))
    );

    $hotelCategoryValue = old(
        'hotel_category',
        $quotation->hotel_category ?? $activeLead?->hotel_category ?? null
    );

    $destinationValue = old(
        'destination',
        $quotation->destination ?? $activeLead?->destination ?? ''
    );

    $subtotalValue = old(
        'subtotal',
        $quotation->subtotal ?? $activeLead?->budget ?? 0
    );

    $defaultTitle = $activeLead
        ? trim($activeLead->destination . ' ' . ($activeLead->duration_days ? $activeLead->duration_days . ' Days ' : '') . 'Travel Package')
        : '';

    $titleValue = old(
        'title',
        $quotation->title ?? $defaultTitle
    );

    $defaultItinerary = $activeLead
        ? 'Suggested ' . $activeLead->destination . ' travel package based on the customer enquiry. '
            . ($activeLead->duration_days ? 'Duration: ' . $activeLead->duration_days . ' day(s). ' : '')
            . ($activeLead->hotel_category ? 'Hotel category: ' . $activeLead->hotel_category . '. ' : '')
            . 'This is the first best available offer and can be revised as per customer preference.'
        : '';

    $itineraryValue = old(
        'itinerary_summary',
        $quotation->itinerary_summary ?? $defaultItinerary
    );

    $inclusionsValue = old(
        'inclusions',
        $quotation->inclusions ?? "Hotel accommodation as per selected category\nDaily breakfast\nSightseeing as per itinerary\nTravel assistance during the trip"
    );

    $exclusionsValue = old(
        'exclusions',
        $quotation->exclusions ?? "Flights unless specifically mentioned\nPersonal expenses\nMeals not mentioned in inclusions\nEntry tickets unless mentioned\nAnything not mentioned in inclusions"
    );

    $termsValue = old(
        'terms',
        $quotation->terms ?? "This offer is subject to availability at the time of booking.\nPrices may change until booking is confirmed.\nBooking will be processed after advance payment.\nCancellation charges may apply as per supplier policy."
    );

    $notesValue = old(
        'notes',
        $quotation->notes ?? ($activeLead?->notes ? 'Lead requirement: ' . $activeLead->notes : '')
    );

    $statusValue = old(
        'status',
        $quotation->status ?? ($statuses[0] ?? 'Draft')
    );

    $validUntilValue = old(
        'valid_until',
        $formatDateForInput($quotation->valid_until ?? null) ?: now()->addDays(7)->format('Y-m-d')
    );

    $customerName = $activeLead?->customer_name ?? $quotation->customer?->full_name ?? 'Customer not selected';
    $customerPhone = $activeLead?->phone ?? $quotation->customer?->phone ?? '—';
    $customerEmail = $activeLead?->email ?? $quotation->customer?->email ?? null;
    $leadSource = $activeLead?->source ?? 'Manual';
@endphp

<form method="POST" action="{{ $action }}" class="space-y-8">
    @csrf

    @if ($method !== 'POST')
        @method($method)
    @endif

    {{-- Lead Summary / First Offer Context --}}
    @if ($hasLeadContext)
        <div class="rounded-xl border border-gray-200 bg-gray-50 p-6">
            <div class="flex items-start justify-between gap-4">
                <div>
                    <h3 class="text-lg font-semibold text-gray-900">
                        Lead Enquiry Summary
                    </h3>
                    <p class="mt-1 text-sm text-gray-500">
                        This offer will be created from the selected lead. Customer and travel details are already captured.
                    </p>
                </div>

                <span class="rounded-full bg-blue-100 px-3 py-1 text-xs font-semibold text-blue-700">
                    First Offer
                </span>
            </div>

            <div class="mt-6 grid grid-cols-1 gap-6 md:grid-cols-5">
                <div>
                    <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Customer</p>
                    <p class="mt-2 font-semibold text-gray-900">{{ $customerName }}</p>
                    <p class="text-sm text-gray-500">{{ $customerPhone }}</p>
                    @if ($customerEmail)
                        <p class="text-xs text-gray-400">{{ $customerEmail }}</p>
                    @endif
                </div>

                <div>
                    <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Destination</p>
                    <p class="mt-2 font-semibold text-gray-900">{{ $destinationValue ?: '—' }}</p>
                    <p class="text-sm text-gray-500">{{ $leadSource }}</p>
                </div>

                <div>
                    <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Travel Plan</p>
                    <p class="mt-2 font-semibold text-gray-900">{{ $formatDateForDisplay($travelStartValue) }}</p>
                    <p class="text-sm text-gray-500">
                        {{ $durationValue ? $durationValue . ' day(s)' : 'Duration not set' }}
                    </p>
                </div>

                <div>
                    <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Pax / Hotel</p>
                    <p class="mt-2 font-semibold text-gray-900">
                        {{ $travellersValue }} traveller(s)
                    </p>
                    <p class="text-sm text-gray-500">
                        {{ $adultsValue ?? 0 }} adult(s), {{ $childrenValue ?? 0 }} child(ren)
                    </p>
                    <p class="text-xs text-gray-400">
                        {{ $hotelCategoryValue ?: 'Hotel not set' }}
                    </p>
                </div>

                <div>
                    <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Budget</p>
                    <p class="mt-2 font-semibold text-gray-900">
                        ₹{{ number_format((float) $subtotalValue) }}
                    </p>
                    <p class="text-sm text-gray-500">Suggested offer price</p>
                </div>
            </div>
        </div>

        {{-- Hidden lead/customer/travel data --}}
        <input type="hidden" name="lead_id" value="{{ old('lead_id', $activeLead->id) }}">
        <input type="hidden" name="destination" value="{{ $destinationValue }}">
        <input type="hidden" name="travel_start_date" value="{{ $travelStartValue }}">
        <input type="hidden" name="travel_end_date" value="{{ old('travel_end_date', $formatDateForInput($quotation->travel_end_date ?? null)) }}">
        <input type="hidden" name="duration_days" value="{{ $durationValue }}">
        <input type="hidden" name="travellers" value="{{ $travellersValue }}">
        <input type="hidden" name="adults" value="{{ $adultsValue }}">
        <input type="hidden" name="children" value="{{ $childrenValue }}">
        <input type="hidden" name="hotel_category" value="{{ $hotelCategoryValue }}">
        <input type="hidden" name="currency" value="{{ old('currency', $quotation->currency ?? 'INR') }}">
        <input type="hidden" name="status" value="{{ $statusValue }}">

        @error('lead_id')
            <p class="text-sm text-red-600">{{ $message }}</p>
        @enderror

        @error('customer_id')
            <p class="text-sm text-red-600">{{ $message }}</p>
        @enderror
    @else
        {{-- Manual quotation mode --}}
        <div class="rounded-xl border border-gray-200 bg-white p-6">
            <h3 class="text-lg font-semibold text-gray-900">
                Customer & Travel Details
            </h3>

            <div class="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
                <div>
                    <label for="customer_id" class="block text-sm font-medium text-gray-700">
                        Customer <span class="text-red-500">*</span>
                    </label>
                    <select
                        id="customer_id"
                        name="customer_id"
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                        <option value="">Select Customer</option>
                        @foreach ($customers as $customer)
                            <option
                                value="{{ $customer->id }}"
                                @selected(old('customer_id', $quotation->customer_id ?? '') == $customer->id)
                            >
                                {{ $customer->full_name }} @if($customer->phone) - {{ $customer->phone }} @endif
                            </option>
                        @endforeach
                    </select>
                    @error('customer_id')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="lead_id" class="block text-sm font-medium text-gray-700">
                        Linked Lead
                    </label>
                    <select
                        id="lead_id"
                        name="lead_id"
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                        <option value="">No linked lead</option>
                        @foreach ($leads as $lead)
                            <option
                                value="{{ $lead->id }}"
                                @selected(old('lead_id', $quotation->lead_id ?? '') == $lead->id)
                            >
                                {{ $lead->customer_name }} - {{ $lead->destination }}
                            </option>
                        @endforeach
                    </select>
                    @error('lead_id')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="destination" class="block text-sm font-medium text-gray-700">
                        Destination <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="text"
                        id="destination"
                        name="destination"
                        value="{{ $destinationValue }}"
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        required
                    >
                    @error('destination')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="travel_start_date" class="block text-sm font-medium text-gray-700">
                        Travel Start Date
                    </label>
                    <input
                        type="date"
                        id="travel_start_date"
                        name="travel_start_date"
                        value="{{ $travelStartValue }}"
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                    @error('travel_start_date')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="duration_days" class="block text-sm font-medium text-gray-700">
                        Duration
                    </label>
                    <input
                        type="number"
                        id="duration_days"
                        name="duration_days"
                        min="1"
                        value="{{ $durationValue }}"
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                    @error('duration_days')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="hotel_category" class="block text-sm font-medium text-gray-700">
                        Hotel Category
                    </label>
                    <input
                        type="text"
                        id="hotel_category"
                        name="hotel_category"
                        value="{{ $hotelCategoryValue }}"
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                    @error('hotel_category')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="adults" class="block text-sm font-medium text-gray-700">
                        Adults
                    </label>
                    <input
                        type="number"
                        id="adults"
                        name="adults"
                        min="0"
                        value="{{ $adultsValue }}"
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                    @error('adults')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="children" class="block text-sm font-medium text-gray-700">
                        Children
                    </label>
                    <input
                        type="number"
                        id="children"
                        name="children"
                        min="0"
                        value="{{ $childrenValue }}"
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                    @error('children')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <input type="hidden" name="travellers" value="{{ $travellersValue }}">
            </div>
        </div>
    @endif

    {{-- Offer Details --}}
    <div class="rounded-xl border border-gray-200 bg-white p-6">
        <h3 class="text-lg font-semibold text-gray-900">
            Best Available Deal
        </h3>
        <p class="mt-1 text-sm text-gray-500">
            The agent can quickly review this first offer, adjust pricing, and share it with the customer.
        </p>

        <div class="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
            <div class="md:col-span-2">
                <label for="title" class="block text-sm font-medium text-gray-700">
                    Package / Deal Title <span class="text-red-500">*</span>
                </label>
                <input
                    type="text"
                    id="title"
                    name="title"
                    value="{{ $titleValue }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    placeholder="Goa 4 Days Travel Package"
                    required
                >
                @error('title')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="subtotal" class="block text-sm font-medium text-gray-700">
                    Offer Price <span class="text-red-500">*</span>
                </label>
                <input
                    type="number"
                    step="0.01"
                    min="0"
                    id="subtotal"
                    name="subtotal"
                    value="{{ $subtotalValue }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                >
                @error('subtotal')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="valid_until" class="block text-sm font-medium text-gray-700">
                    Offer Valid Until
                </label>
                <input
                    type="date"
                    id="valid_until"
                    name="valid_until"
                    value="{{ $validUntilValue }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('valid_until')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="discount" class="block text-sm font-medium text-gray-700">
                    Discount
                </label>
                <input
                    type="number"
                    step="0.01"
                    min="0"
                    id="discount"
                    name="discount"
                    value="{{ old('discount', $quotation->discount ?? 0) }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('discount')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="tax" class="block text-sm font-medium text-gray-700">
                    Tax
                </label>
                <input
                    type="number"
                    step="0.01"
                    min="0"
                    id="tax"
                    name="tax"
                    value="{{ old('tax', $quotation->tax ?? 0) }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                @error('tax')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            @unless ($hasLeadContext)
                <div>
                    <label for="currency" class="block text-sm font-medium text-gray-700">
                        Currency
                    </label>
                    <input
                        type="text"
                        id="currency"
                        name="currency"
                        value="{{ old('currency', $quotation->currency ?? 'INR') }}"
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        required
                    >
                    @error('currency')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="status" class="block text-sm font-medium text-gray-700">
                        Status
                    </label>
                    <select
                        id="status"
                        name="status"
                        class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                        @foreach ($statuses as $status)
                            <option value="{{ $status }}" @selected($statusValue === $status)>
                                {{ $status }}
                            </option>
                        @endforeach
                    </select>
                    @error('status')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            @endunless
        </div>

        <div class="mt-6">
            <label for="itinerary_summary" class="block text-sm font-medium text-gray-700">
                Itinerary Summary
            </label>
            <textarea
                id="itinerary_summary"
                name="itinerary_summary"
                rows="4"
                class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="Brief package summary..."
            >{{ $itineraryValue }}</textarea>
            @error('itinerary_summary')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>

        <div class="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
            <div>
                <label for="inclusions" class="block text-sm font-medium text-gray-700">
                    Inclusions
                </label>
                <textarea
                    id="inclusions"
                    name="inclusions"
                    rows="6"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >{{ $inclusionsValue }}</textarea>
                @error('inclusions')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="exclusions" class="block text-sm font-medium text-gray-700">
                    Exclusions
                </label>
                <textarea
                    id="exclusions"
                    name="exclusions"
                    rows="6"
                    class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >{{ $exclusionsValue }}</textarea>
                @error('exclusions')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>
        </div>

        <div class="mt-6">
            <label for="terms" class="block text-sm font-medium text-gray-700">
                Terms & Conditions
            </label>
            <textarea
                id="terms"
                name="terms"
                rows="5"
                class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            >{{ $termsValue }}</textarea>
            @error('terms')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>

        <div class="mt-6">
            <label for="notes" class="block text-sm font-medium text-gray-700">
                Notes
            </label>
            <textarea
                id="notes"
                name="notes"
                rows="3"
                class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="Internal note or customer-specific requirement..."
            >{{ $notesValue }}</textarea>
            @error('notes')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="flex items-center justify-end gap-3">
        <a
            href="{{ $hasLeadContext ? route('leads.show', $activeLead) : route('quotations.index') }}"
            class="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50"
        >
            Cancel
        </a>

        <button
            type="submit"
            class="rounded-lg bg-indigo-600 px-5 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700"
        >
            Send Offer
            
        </button>
    </div>
</form>
