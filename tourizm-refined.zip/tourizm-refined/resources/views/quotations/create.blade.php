<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">
                    Create First Offer
                </h2>
                <p class="mt-1 text-sm text-gray-500">
                    Prepare a quick travel deal from the lead enquiry.
                </p>
            </div>

            <a
                href="{{ route('quotations.index') }}"
                class="rounded-lg bg-gray-800 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-700"
            >
                Back to Quotations
            </a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div class="rounded-xl bg-white p-6 shadow-sm">
                @include('quotations._form', [
                    'action' => route('quotations.store'),
                    'method' => 'POST',
                    'buttonText' => 'Create First Offer',
                    'selectedLead' => $selectedLead ?? null,
                ])
            </div>
        </div>
    </div>
</x-app-layout>
