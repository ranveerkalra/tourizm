<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Get Quote - Tourizm AI</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-50 text-gray-900">

    <div class="min-h-screen px-6 py-12">
        <div class="mx-auto max-w-4xl">

            <div class="mb-8">
                <a
                    href="{{ url()->previous() }}"
                    class="text-sm font-semibold text-gray-600 hover:text-gray-900"
                >
                    ← Back to trip ideas
                </a>

                <h1 class="mt-4 text-3xl font-bold text-gray-900">
                    Get Quote for {{ $destination }}
                </h1>

                <p class="mt-2 text-gray-600">
                    Share your details and we will create a lead inside Tourizm AI CRM.
                </p>
            </div>

            <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

                <div class="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm lg:col-span-1">
                    <div class="inline-flex rounded-full bg-green-50 px-3 py-1 text-sm font-semibold text-green-700">
                        Selected Plan
                    </div>

                    <h2 class="mt-4 text-2xl font-bold text-gray-900">
                        {{ $selectedPlan['title'] }}
                    </h2>

                    <p class="mt-2 font-semibold text-gray-700">
                        {{ $selectedPlan['route'] }}
                    </p>

                    <p class="mt-4 text-sm text-gray-600">
                        {{ $selectedPlan['description'] }}
                    </p>

                    <div class="mt-6 rounded-xl bg-gray-50 p-4">
                        <p class="text-sm text-gray-500">Starting from</p>
                        <p class="text-2xl font-bold text-gray-900">
                            ₹{{ number_format($selectedPlan['price']) }}
                        </p>
                        <p class="text-sm text-gray-500">per person</p>
                    </div>
                </div>

                <div class="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm lg:col-span-2">

                    @if ($errors->any())
                        <div class="mb-6 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                            Please check the form and try again.
                        </div>
                    @endif

                    <form action="{{ route('trip-planner.store') }}" method="POST">
                        @csrf

                        <input type="hidden" name="destination" value="{{ $destination }}">
                        <input type="hidden" name="selected_plan" value="{{ $selectedPlan['title'] }} - {{ $selectedPlan['route'] }}">

                        <div class="grid grid-cols-1 gap-5 md:grid-cols-2">

                            <div>
                                <label class="block text-sm font-semibold text-gray-700">
                                    Full Name <span class="text-red-500">*</span>
                                </label>
                                <input
                                    type="text"
                                    name="customer_name"
                                    value="{{ old('customer_name') }}"
                                    class="mt-2 w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                                    required
                                >
                                @error('customer_name')
                                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            <div>
                                <label class="block text-sm font-semibold text-gray-700">
                                    Phone Number <span class="text-red-500">*</span>
                                </label>
                                <input
                                    type="text"
                                    name="phone"
                                    value="{{ old('phone') }}"
                                    class="mt-2 w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                                    required
                                >
                                @error('phone')
                                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            <div>
                                <label class="block text-sm font-semibold text-gray-700">
                                    Email
                                </label>
                                <input
                                    type="email"
                                    name="email"
                                    value="{{ old('email') }}"
                                    class="mt-2 w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                                >
                                @error('email')
                                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            <div>
                                <label class="block text-sm font-semibold text-gray-700">
                                    Departure City
                                </label>
                                <input
                                    type="text"
                                    name="departure_city"
                                    value="{{ old('departure_city') }}"
                                    placeholder="Example: Delhi"
                                    class="mt-2 w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                                >
                                @error('departure_city')
                                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            <div>
                                <label class="block text-sm font-semibold text-gray-700">
                                    Travel Date
                                </label>
                                <input
                                    type="date"
                                    name="travel_date"
                                    value="{{ old('travel_date') }}"
                                    class="mt-2 w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                                >
                                @error('travel_date')
                                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            <div>
                                <label class="block text-sm font-semibold text-gray-700">
                                    Number of Travellers <span class="text-red-500">*</span>
                                </label>
                                <input
                                    type="number"
                                    name="travellers"
                                    value="{{ old('travellers', 2) }}"
                                    min="1"
                                    class="mt-2 w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                                    required
                                >
                                @error('travellers')
                                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            <div class="md:col-span-2">
    <label class="block text-sm font-semibold text-gray-700">
        Accommodation Preference <span class="text-red-500">*</span>
    </label>

    <div class="mt-3 grid grid-cols-1 gap-4 md:grid-cols-4">
        @foreach (['Budget', '3 Star', '4 Star', 'Luxury'] as $hotel)
            <label class="cursor-pointer rounded-xl border border-gray-300 p-4 text-center hover:border-blue-500 hover:bg-blue-50">
                <input
                    type="radio"
                    name="hotel_category"
                    value="{{ $hotel }}"
                    class="mb-3"
                    {{ old('hotel_category', 'Budget') === $hotel ? 'checked' : '' }}
                    required
                >

                <div class="font-semibold text-gray-900">
                    {{ $hotel }}
                </div>

                <div class="mt-1 text-sm text-gray-500">
                    @if ($hotel === 'Budget')
                        Budget-friendly stay
                    @elseif ($hotel === '3 Star')
                        Comfortable stay
                    @elseif ($hotel === '4 Star')
                        Premium comfort
                    @else
                        Luxury experience
                    @endif
                </div>
            </label>
        @endforeach
    </div>

    @error('hotel_category')
        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
    @enderror
</div>
                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold text-gray-700">
                                    Notes / Special Request
                                </label>
                                <textarea
                                    name="notes"
                                    rows="4"
                                    placeholder="Example: Need 4-star hotels, honeymoon package, vegetarian meals..."
                                    class="mt-2 w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                                >{{ old('notes') }}</textarea>
                                @error('notes')
                                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                        </div>

                        <div class="mt-6">
                            <button
                                type="submit"
                                class="w-full rounded-lg bg-green-600 px-6 py-3 font-semibold text-white hover:bg-green-700"
                            >
                                Submit Request
                            </button>
                        </div>

                    </form>
                </div>

            </div>

        </div>
    </div>

</body>
</html>
