<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tourizm AI Trip Planner</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-50 text-gray-900">

    <div class="min-h-screen flex items-center justify-center px-6">
        <div class="w-full max-w-3xl bg-white rounded-2xl shadow-sm border border-gray-200 p-10 text-center">

            <h1 class="text-4xl font-bold text-gray-900">
                Where do you want to travel?
            </h1>

            <p class="mt-4 text-gray-600">
                Tell us your destination and Tourizm AI will suggest quick travel ideas.
            </p>

            @if (session('success'))
                <div class="mt-6 rounded-lg bg-green-50 border border-green-200 px-4 py-3 text-green-700">
                    {{ session('success') }}
                </div>
            @endif

            @if (session('error'))
                <div class="mt-6 rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-red-700">
                    {{ session('error') }}
                </div>
            @endif

            <form action="{{ route('trip-planner.search') }}" method="POST" class="mt-8">
                @csrf

                <div class="flex flex-col md:flex-row gap-3">
                    <input
                        type="text"
                        name="destination"
                        value="{{ old('destination') }}"
                        placeholder="Example: Kerala"
                        class="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                        required
                    >

                    <button
                        type="submit"
                        class="rounded-lg bg-green-600 px-8 py-3 text-white font-semibold hover:bg-green-700"
                    >
                        Search
                    </button>
                </div>

                @error('destination')
                    <p class="mt-2 text-sm text-red-600 text-left">{{ $message }}</p>
                @enderror
            </form>

            <div class="mt-10 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div class="rounded-xl bg-green-50 p-4">
                    <div class="font-semibold text-green-700">Quick & Easy</div>
                    <div class="text-gray-600 mt-1">Plan in minutes</div>
                </div>

                <div class="rounded-xl bg-blue-50 p-4">
                    <div class="font-semibold text-blue-700">AI-Powered</div>
                    <div class="text-gray-600 mt-1">Smart trip ideas</div>
                </div>

                <div class="rounded-xl bg-gray-50 p-4">
                    <div class="font-semibold text-gray-700">Lead Ready</div>
                    <div class="text-gray-600 mt-1">Creates CRM enquiry</div>
                </div>
            </div>

        </div>
    </div>

</body>
</html>
