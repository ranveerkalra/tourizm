<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                Travel Request Details
            </h2>
            <p class="mt-1 text-sm text-gray-500">
                Review traveler requirement before claiming this request.
            </p>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
            <div class="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
                <h3 class="text-2xl font-bold text-gray-900">
                    {{ $travelRequest->destination }} Travel Request
                </h3>

                <div class="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div>
                        <p class="text-sm text-gray-500">Customer</p>
                        <p class="font-semibold text-gray-900">{{ $travelRequest->customer_name }}</p>
                    </div>

                    <div>
                        <p class="text-sm text-gray-500">Phone</p>
                        <p class="font-semibold text-gray-900">{{ $travelRequest->phone }}</p>
                    </div>

                    <div>
                        <p class="text-sm text-gray-500">Destination</p>
                        <p class="font-semibold text-gray-900">{{ $travelRequest->destination }}</p>
                    </div>

                    <div>
                        <p class="text-sm text-gray-500">Budget</p>
                        <p class="font-semibold text-gray-900">
                            {{ $travelRequest->budget ? '₹' . number_format($travelRequest->budget) : 'Not provided' }}
                        </p>
                    </div>
                </div>

                <div class="mt-6">
                    <a
                        href="{{ route('marketplace.travel-requests.index') }}"
                        class="rounded-lg border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100"
                    >
                        Back to Marketplace
                    </a>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
