<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">
                    Marketplace Travel Requests
                </h2>
                <p class="mt-1 text-sm text-gray-500">
                    Anonymous incoming traveler requests available for agencies to claim.
                </p>
            </div>

        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

            <div class="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">

                <div class="border-b border-gray-200 bg-white p-5">
                    <div class="grid grid-cols-1 gap-4 md:grid-cols-5">
                        <input
                            type="text"
                            placeholder="Search by destination..."
                            class="rounded-lg border-gray-300 text-sm focus:border-blue-500 focus:ring-blue-500"
                        >

                        <select class="rounded-lg border-gray-300 text-sm focus:border-blue-500 focus:ring-blue-500">
                            <option>All Status</option>
                            <option>Available</option>
                            <option>Claimed</option>
                            <option>Converted</option>
                        </select>

                        <select class="rounded-lg border-gray-300 text-sm focus:border-blue-500 focus:ring-blue-500">
                            <option>All Destinations</option>
                        </select>

                        <button type="button"
                                class="rounded-lg border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100">
                            Clear
                        </button>

                        <a href="{{ route('marketplace.travel-requests.index') }}"
                           class="rounded-lg border border-green-300 bg-green-50 px-4 py-2 text-center text-sm font-semibold text-green-700 hover:bg-green-100">
                            Refresh
                        </a>
                    </div>
                </div>

                @if ($travelRequests->count())
                    <div class="overflow-x-auto">
                       <table class="w-full table-fixed divide-y divide-gray-200 text-sm">
                            <thead class="bg-gray-50">
<tr>
    <th class="w-[105px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Request</th>
    <th class="w-[95px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Destination</th>
    <th class="w-[190px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Travel Plan</th>
    <th class="w-[105px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Traveler(s)</th>
    <th class="w-[90px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Hotel</th>
    <th class="w-[115px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Source</th>
    <th class="w-[95px] px-3 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-600">Status</th>
    <th class="w-[120px] px-3 py-3 text-center text-xs font-bold uppercase tracking-wider text-gray-600">Action</th>
</tr>
</thead>

                            <tbody class="divide-y divide-gray-100 bg-white">
                                @foreach ($travelRequests as $request)
                                    @php
                                        $selectedPlan = $request->selected_plan ?? '';
                                        $planTitle = $selectedPlan;

                                        if (str_contains($selectedPlan, ' - ')) {
                                            $planTitle = trim(str($selectedPlan)->after(' - '));
                                        }

                                        $durationLabel = $request->duration_days
                                            ? $request->duration_days . ' Days / ' . max($request->duration_days - 1, 0) . ' Nights'
                                            : 'Duration pending';

                                        $hotelBadge = match($request->hotel_category) {
                                            'Budget' => 'bg-green-100 text-green-700',
                                            '3 Star' => 'bg-blue-100 text-blue-700',
                                            '4 Star' => 'bg-purple-100 text-purple-700',
                                            'Luxury' => 'bg-yellow-100 text-yellow-800',
                                            default => 'bg-gray-100 text-gray-700',
                                        };

                                        $statusClasses = match ($request->status) {
                                            'Available' => 'bg-blue-100 text-blue-700',
                                            'Claimed' => 'bg-yellow-100 text-yellow-700',
                                            'Converted' => 'bg-green-100 text-green-700',
                                            default => 'bg-gray-100 text-gray-700',
                                        };
                                    @endphp

                                    <tr class="hover:bg-gray-50">
                                        <td class="px-3 py-4 align-top">
                                            <div class="text-sm font-semibold text-gray-900 whitespace-nowrap">
                                                TR-{{ str_pad($request->id, 6, '0', STR_PAD_LEFT) }}
                                            </div>

                                            <div class="mt-1 text-xs text-gray-400">
                                                {{ $request->created_at->diffForHumans() }}
                                            </div>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <div class="text-sm font-semibold text-gray-900">
                                                {{ ucfirst($request->destination) }}
                                            </div>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <div class="text-sm font-semibold text-gray-900 leading-6">
                                                {{ $planTitle ?: 'Plan not selected' }}
                                            </div>

                                            <div class="mt-1 text-sm text-gray-500">
                                                {{ $request->travel_date
                                                    ? $request->travel_date->format('d M Y')
                                                    : 'Travel date pending' }}
                                            </div>

                                            <div class="mt-1 text-xs text-gray-400">
                                                {{ $durationLabel }}
                                            </div>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <div class="text-sm font-semibold text-gray-900 whitespace-nowrap">
                                                {{ $request->travellers }} Travelers
                                            </div>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <span class="inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap {{ $hotelBadge }}">
                                                {{ $request->hotel_category ?? 'Pending' }}
                                            </span>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <div class="text-sm font-semibold text-gray-700">
                                                AI Trip Planner
                                            </div>
                                        </td>

                                        <td class="px-3 py-4 align-top">
                                            <span class="inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap {{ $statusClasses }}">
                                                {{ $request->status }}
                                            </span>
                                        </td>

                                       <td class="px-3 py-4 align-top text-center">
    @if ($request->status === 'Available')
        <form action="{{ route('marketplace.travel-requests.claim', $request) }}" method="POST">
            @csrf

            <button type="submit"
                    class="inline-flex w-full justify-center rounded-lg border border-green-300 bg-green-50 px-2 py-2 text-sm font-semibold text-green-700 hover:bg-green-100">
                Claim
            </button>
        </form>
    @else
        <span class="inline-flex w-full justify-center rounded-lg border border-yellow-300 bg-yellow-50 px-2 py-2 text-sm font-semibold text-yellow-700">
            Claimed
        </span>
    @endif
</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div class="border-t border-gray-200 px-6 py-4">
                        {{ $travelRequests->links() }}
                    </div>
                @else
                    <div class="p-12 text-center">
                        <div class="text-5xl">🧳</div>

                        <h3 class="mt-4 text-xl font-bold text-gray-900">
                            No Travel Requests Available
                        </h3>

                        <p class="mt-2 text-gray-600">
                            New website and AI trip planner requests will appear here.
                        </p>
                    </div>
                @endif

            </div>

        </div>
    </div>
</x-app-layout>
