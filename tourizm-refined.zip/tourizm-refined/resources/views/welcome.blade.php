<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ config('app.name', 'Tourizm AI') }}</title>
    <meta name="description" content="Tourizm AI is a modern CRM for travel agencies to capture leads, buy requests, reply faster and close more trips.">
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600,700,800,900&display=swap" rel="stylesheet" />
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-slate-950 font-sans text-white antialiased">
    <div class="relative isolate min-h-screen overflow-hidden">
        <div class="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.24),transparent_32%),radial-gradient(circle_at_80%_20%,rgba(59,130,246,0.28),transparent_28%),linear-gradient(135deg,#020617_0%,#0f172a_55%,#111827_100%)]"></div>
        <div class="absolute left-1/2 top-16 -z-10 h-96 w-96 -translate-x-1/2 rounded-full bg-cyan-400/10 blur-3xl"></div>

        <header class="mx-auto flex max-w-7xl items-center justify-between px-6 py-6 lg:px-8">
            <a href="{{ url('/') }}" class="flex items-center gap-3">
                <div class="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 via-cyan-400 to-emerald-400 text-lg font-black text-slate-950 shadow-lg shadow-cyan-500/20">T</div>
                <div>
                    <p class="text-lg font-black tracking-tight">Tourizm AI</p>
                    <p class="text-[11px] font-bold uppercase tracking-[0.28em] text-cyan-200/70">Travel CRM</p>
                </div>
            </a>

            <nav class="hidden items-center gap-8 text-sm font-bold text-slate-300 md:flex">
                <a href="#features" class="hover:text-white">Features</a>
                <a href="#workflow" class="hover:text-white">Workflow</a>
                <a href="#pricing" class="hover:text-white">Pricing</a>
            </nav>

            <div class="flex items-center gap-3">
                @auth
                    <a href="{{ route(auth()->user()->homeRoute()) }}" class="rounded-2xl bg-white px-4 py-2 text-sm font-black text-slate-950 transition hover:bg-cyan-50">Dashboard</a>
                @else
                    <a href="{{ route('login') }}" class="hidden rounded-2xl border border-white/15 px-4 py-2 text-sm font-black text-white transition hover:bg-white/10 sm:inline-flex">Login</a>
                    <a href="{{ route('register') }}" class="rounded-2xl bg-white px-4 py-2 text-sm font-black text-slate-950 transition hover:bg-cyan-50">Start Free</a>
                @endauth
            </div>
        </header>

        <main>
            <section class="mx-auto grid max-w-7xl items-center gap-12 px-6 pb-20 pt-10 lg:grid-cols-[0.95fr_1.05fr] lg:px-8 lg:pb-28 lg:pt-16">
                <div>
                    <div class="mb-6 inline-flex rounded-full border border-cyan-300/20 bg-cyan-300/10 px-4 py-2 text-xs font-black uppercase tracking-[0.24em] text-cyan-100">CRM + Buy Leads + AI Replies</div>
                    <h1 class="max-w-4xl text-5xl font-black leading-[0.98] tracking-tight sm:text-6xl lg:text-7xl">Close travel enquiries before your competitors reply.</h1>
                    <p class="mt-6 max-w-2xl text-lg leading-8 text-slate-300">A polished Laravel SaaS starter for travel agents: capture leads, buy travel requests, assign consultants, create quotations and prepare AI-assisted responses from one clean dashboard.</p>

                    <div class="mt-8 flex flex-col gap-3 sm:flex-row">
                        <a href="{{ route('register') }}" class="rounded-2xl bg-cyan-300 px-6 py-4 text-center text-sm font-black text-slate-950 shadow-xl shadow-cyan-500/20 transition hover:bg-cyan-200">Create Agency Workspace</a>
                        <a href="{{ route('login') }}" class="rounded-2xl border border-white/15 bg-white/10 px-6 py-4 text-center text-sm font-black text-white backdrop-blur transition hover:bg-white/15">View Dashboard</a>
                    </div>

                    <div class="mt-10 grid grid-cols-3 gap-4 max-w-xl">
                        <div class="rounded-3xl border border-white/10 bg-white/5 p-4 backdrop-blur">
                            <p class="text-3xl font-black">3x</p>
                            <p class="mt-1 text-xs font-semibold text-slate-400">faster replies</p>
                        </div>
                        <div class="rounded-3xl border border-white/10 bg-white/5 p-4 backdrop-blur">
                            <p class="text-3xl font-black">24/7</p>
                            <p class="mt-1 text-xs font-semibold text-slate-400">lead capture</p>
                        </div>
                        <div class="rounded-3xl border border-white/10 bg-white/5 p-4 backdrop-blur">
                            <p class="text-3xl font-black">AI</p>
                            <p class="mt-1 text-xs font-semibold text-slate-400">quote draft</p>
                        </div>
                    </div>
                </div>

                <div class="relative">
                    <div class="absolute -inset-4 -z-10 rounded-[2.5rem] bg-cyan-400/20 blur-3xl"></div>
                    <div class="overflow-hidden rounded-[2rem] border border-white/10 bg-white/10 p-3 shadow-2xl backdrop-blur-xl">
                        <div class="rounded-[1.5rem] bg-slate-100 p-4 text-slate-950">
                            <div class="mb-4 flex items-center justify-between">
                                <div>
                                    <p class="text-sm font-black">Agency Command Center</p>
                                    <p class="text-xs font-semibold text-slate-500">Today’s high-intent travel pipeline</p>
                                </div>
                                <span class="rounded-full bg-emerald-100 px-3 py-1 text-xs font-black text-emerald-700">Live</span>
                            </div>

                            <div class="grid grid-cols-2 gap-3 sm:grid-cols-4">
                                @foreach ([['Leads','128','🎯'], ['Qualified','43','🔥'], ['Booked','19','✅'], ['Pipeline','₹18L','💰']] as $card)
                                    <div class="rounded-2xl bg-white p-4 shadow-sm">
                                        <div class="text-xl">{{ $card[2] }}</div>
                                        <p class="mt-3 text-2xl font-black">{{ $card[1] }}</p>
                                        <p class="text-xs font-bold text-slate-500">{{ $card[0] }}</p>
                                    </div>
                                @endforeach
                            </div>

                            <div class="mt-4 grid gap-3 lg:grid-cols-[1.2fr_0.8fr]">
                                <div class="rounded-2xl bg-white p-4 shadow-sm">
                                    <div class="mb-4 flex items-center justify-between">
                                        <p class="text-sm font-black">Lead trend</p>
                                        <p class="text-xs font-bold text-blue-600">+28%</p>
                                    </div>
                                    <div class="flex h-44 items-end gap-2">
                                        @foreach ([34, 55, 42, 74, 63, 88, 70, 104, 92, 118, 132, 128] as $bar)
                                            <div class="flex-1 rounded-t-xl bg-gradient-to-t from-blue-600 to-cyan-300" style="height: {{ $bar }}px"></div>
                                        @endforeach
                                    </div>
                                </div>

                                <div class="rounded-2xl bg-slate-950 p-4 text-white shadow-sm">
                                    <p class="text-sm font-black">AI Reply Draft</p>
                                    <div class="mt-4 rounded-2xl bg-white/10 p-3 text-xs leading-5 text-slate-300">“Hi Priya, based on your Kerala family trip, I’ve prepared a 6-day plan with Munnar, Thekkady and Alleppey...”</div>
                                    <button class="mt-4 w-full rounded-2xl bg-cyan-300 px-4 py-3 text-sm font-black text-slate-950">Send on WhatsApp</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id="features" class="border-y border-white/10 bg-white/[0.03] py-20">
                <div class="mx-auto max-w-7xl px-6 lg:px-8">
                    <div class="max-w-3xl">
                        <p class="text-sm font-black uppercase tracking-[0.26em] text-cyan-200">What’s inside</p>
                        <h2 class="mt-3 text-3xl font-black tracking-tight sm:text-5xl">Everything a travel agency dashboard needs first.</h2>
                    </div>

                    <div class="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                        @foreach ([
                            ['🎯', 'Lead CRM', 'Capture, search, filter, assign and track every enquiry from first contact to win/loss.'],
                            ['🧲', 'Buy Leads', 'Marketplace-ready screen for fresh travel requests and lead claiming.'],
                            ['🧾', 'Quotations', 'Create package quotations with duration, hotels, inclusions, exclusions and status flow.'],
                            ['👥', 'Team Roles', 'Admin, manager and executive permissions with a cleaner sidebar experience.'],
                        ] as $feature)
                            <div class="rounded-[1.75rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
                                <div class="text-3xl">{{ $feature[0] }}</div>
                                <h3 class="mt-5 text-lg font-black">{{ $feature[1] }}</h3>
                                <p class="mt-3 text-sm leading-6 text-slate-400">{{ $feature[2] }}</p>
                            </div>
                        @endforeach
                    </div>
                </div>
            </section>

            <section id="workflow" class="mx-auto max-w-7xl px-6 py-20 lg:px-8">
                <div class="grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:items-start">
                    <div>
                        <p class="text-sm font-black uppercase tracking-[0.26em] text-cyan-200">Workflow</p>
                        <h2 class="mt-3 text-3xl font-black tracking-tight sm:text-5xl">From lead to booking without chaos.</h2>
                        <p class="mt-5 text-base leading-7 text-slate-400">The product is structured like a real SaaS: public landing, auth, dashboard, CRM modules, marketplace, roles and database migrations.</p>
                    </div>
                    <div class="grid gap-4 sm:grid-cols-2">
                        @foreach ([
                            ['01', 'Lead enters CRM', 'Website, WhatsApp, Instagram, referral or marketplace request.'],
                            ['02', 'Consultant follows up', 'Assign owner, add notes, qualify budget and travel details.'],
                            ['03', 'Quotation sent', 'Build a package and move the deal through sent/accepted/rejected.'],
                            ['04', 'Booking operations', 'Next modules can handle vendors, vouchers, payments and reports.'],
                        ] as $step)
                            <div class="rounded-[1.75rem] border border-white/10 bg-white/5 p-6">
                                <p class="text-sm font-black text-cyan-200">{{ $step[0] }}</p>
                                <h3 class="mt-4 text-xl font-black">{{ $step[1] }}</h3>
                                <p class="mt-3 text-sm leading-6 text-slate-400">{{ $step[2] }}</p>
                            </div>
                        @endforeach
                    </div>
                </div>
            </section>

            <section id="pricing" class="mx-auto max-w-7xl px-6 pb-24 lg:px-8">
                <div class="rounded-[2rem] border border-white/10 bg-white p-6 text-slate-950 shadow-2xl sm:p-8 lg:p-10">
                    <div class="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-center">
                        <div>
                            <p class="text-sm font-black uppercase tracking-[0.24em] text-blue-600">Ready for development</p>
                            <h2 class="mt-3 text-3xl font-black tracking-tight sm:text-5xl">Use this ZIP as your Laravel SaaS base.</h2>
                            <p class="mt-4 max-w-3xl text-base leading-7 text-slate-600">Start with CRM, marketplace and quotations. Then plug in Razorpay, WhatsApp API, AI replies, lead scoring and subscription billing.</p>
                        </div>
                        <a href="{{ route('register') }}" class="rounded-2xl bg-slate-950 px-7 py-4 text-center text-sm font-black text-white transition hover:bg-slate-800">Launch Workspace</a>
                    </div>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
