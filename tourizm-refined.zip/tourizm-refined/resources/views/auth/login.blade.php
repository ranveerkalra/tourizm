<x-guest-layout>
    <div class="mb-6 text-center">
        <h1 class="text-2xl font-black tracking-tight text-slate-950">Welcome back</h1>
        <p class="mt-2 text-sm font-semibold text-slate-500">Login to your agency workspace.</p>
    </div>

    <x-auth-session-status class="mb-4" :status="session('status')" />

    <form method="POST" action="{{ route('login') }}" class="space-y-5">
        @csrf

        <div>
            <x-input-label for="email" :value="__('Email')" />
            <x-text-input id="email" class="mt-2 block w-full" type="email" name="email" :value="old('email')" required autofocus autocomplete="username" />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <div>
            <x-input-label for="password" :value="__('Password')" />
            <x-text-input id="password" class="mt-2 block w-full" type="password" name="password" required autocomplete="current-password" />
            <x-input-error :messages="$errors->get('password')" class="mt-2" />
        </div>

        <div class="flex items-center justify-between gap-4">
            <label for="remember_me" class="inline-flex items-center">
                <input id="remember_me" type="checkbox" class="rounded border-slate-300 text-cyan-600 shadow-sm focus:ring-cyan-500" name="remember">
                <span class="ms-2 text-sm font-semibold text-slate-600">{{ __('Remember me') }}</span>
            </label>

            @if (Route::has('password.request'))
                <a class="text-sm font-bold text-blue-600 hover:text-blue-700" href="{{ route('password.request') }}">Forgot?</a>
            @endif
        </div>

        <x-primary-button class="w-full">{{ __('Log in') }}</x-primary-button>

        <p class="text-center text-sm font-semibold text-slate-500">
            New agency?
            <a href="{{ route('register') }}" class="font-black text-blue-600 hover:text-blue-700">Create workspace</a>
        </p>
    </form>
</x-guest-layout>
