<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\LeadController;
use App\Http\Controllers\MarketplaceController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PublicTripPlannerController;
use App\Http\Controllers\QuotationController;
use App\Http\Controllers\TeamMemberController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public Routes
|--------------------------------------------------------------------------
*/

Route::view('/', 'welcome');

Route::get('/trip-planner', [PublicTripPlannerController::class, 'index'])
    ->name('trip-planner.index');

Route::post('/trip-planner/search', [PublicTripPlannerController::class, 'search'])
    ->name('trip-planner.search');

Route::get('/trip-planner/quote/{destination}/{plan}', [PublicTripPlannerController::class, 'quote'])
    ->name('trip-planner.quote');

Route::post('/trip-planner/quote', [PublicTripPlannerController::class, 'store'])
    ->name('trip-planner.store');

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified', 'role:admin'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])
        ->name('dashboard');

    Route::get('/permissions', [PermissionController::class, 'index'])
        ->name('permissions.index');

    Route::put('/permissions/roles/{role}', [PermissionController::class, 'updateRole'])
        ->name('permissions.roles.update');
});

/*
|--------------------------------------------------------------------------
| CRM Routes
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('leads', LeadController::class);
    Route::get('/leads/{lead}/assign', [LeadController::class, 'assign'])
        ->name('leads.assign');
    Route::patch('/leads/{lead}/assign', [LeadController::class, 'updateAssignment'])
        ->name('leads.updateAssignment');

    Route::resource('customers', CustomerController::class);
    Route::resource('quotations', QuotationController::class);
    Route::resource('team-members', TeamMemberController::class);

    Route::get('/marketplace/travel-requests', [MarketplaceController::class, 'index'])
        ->name('marketplace.travel-requests.index');

    Route::get('/marketplace/travel-requests/{travelRequest}', [MarketplaceController::class, 'show'])
        ->name('marketplace.travel-requests.show');

    Route::post('/marketplace/travel-requests/{travelRequest}/claim', [MarketplaceController::class, 'claim'])
        ->name('marketplace.travel-requests.claim');

    Route::patch('/quotations/{quotation}/send', [QuotationController::class, 'send'])
        ->name('quotations.send');

    Route::patch('/quotations/{quotation}/accept', [QuotationController::class, 'accept'])
        ->name('quotations.accept');

    Route::patch('/quotations/{quotation}/reject', [QuotationController::class, 'reject'])
        ->name('quotations.reject');

    Route::patch('/quotations/{quotation}/expire', [QuotationController::class, 'expire'])
        ->name('quotations.expire');
});

/*
|--------------------------------------------------------------------------
| Profile Routes
|--------------------------------------------------------------------------
*/

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])
        ->name('profile.edit');

    Route::patch('/profile', [ProfileController::class, 'update'])
        ->name('profile.update');

    Route::delete('/profile', [ProfileController::class, 'destroy'])
        ->name('profile.destroy');
});

require __DIR__.'/auth.php';
