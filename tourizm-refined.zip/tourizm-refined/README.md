# Tourizm AI — Laravel Travel CRM SaaS Starter

A refined Laravel CRM starter for travel agencies. It includes a polished landing page, authenticated agency dashboard, lead CRM, buy-leads marketplace, customers, quotations, team members and role-based permissions.

## What is improved in this ZIP

- Rebuilt the public landing page into a professional SaaS homepage.
- Rebuilt the dashboard into a full-screen travel CRM command center.
- Added cleaner dark sidebar navigation with Dashboard, Buy Leads, Leads, Customers and Quotations.
- Fixed owner registration so the first user becomes an `admin` and can access `/dashboard`.
- Fixed role redirects through a reusable `homeRoute()` method.
- Moved lead assignment routes behind `auth` middleware.
- Removed the broken Vite dev `public/hot` file from the final package.
- Removed `.env`, `.git`, `vendor` and `node_modules` from the final package so it is GitHub/deployment friendly.
- Added demo seed users and sample leads.

## Requirements

- PHP 8.3 or newer
- Composer
- Node.js 20 or newer
- MySQL 8+ or MariaDB

This project is currently Laravel 13, so PHP 8.0 will not run it. Use PHP 8.3+ locally or on Hostinger.

## Quick setup

```bash
composer install
npm install
copy .env.example .env
php artisan key:generate
```

Edit `.env` database values:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=tourizm
DB_USERNAME=root
DB_PASSWORD=
```

Then run:

```bash
php artisan migrate --seed
npm run build
php artisan serve
```

Open:

```text
http://127.0.0.1:8000
```

## Demo login after seeding

```text
Admin: admin@demo.test / password
Manager: manager@demo.test / password
Executive: executive@demo.test / password
```

## Main URLs

```text
/                  Landing page
/login             Login
/register          Create agency workspace
/dashboard         Admin dashboard
/leads             Lead CRM
/marketplace/travel-requests   Buy leads marketplace
/customers         Customers
/quotations        Quotations
/team-members      Team members
/permissions       Role permissions
```

## Deployment notes

Do not upload `node_modules`, `vendor`, `.git` or `.env` to GitHub. On hosting, install Composer dependencies, create your production `.env`, run migrations, then build frontend assets.

For Hostinger, set the domain document root to the Laravel `public` folder.
